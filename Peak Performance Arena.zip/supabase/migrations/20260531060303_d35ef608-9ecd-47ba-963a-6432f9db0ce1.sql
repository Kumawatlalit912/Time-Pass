
-- Profiles
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL DEFAULT 'Player',
  avatar_color TEXT NOT NULL DEFAULT '#3b82f6',
  total_xp INT NOT NULL DEFAULT 0,
  matches_played INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT SELECT ON public.profiles TO anon;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Profiles readable by all" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id);
CREATE POLICY "Users insert own profile" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name, avatar_color)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1), 'Player'),
    (ARRAY['#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6','#06b6d4','#ec4899','#84cc16','#f97316','#6366f1'])[1 + floor(random()*10)::int]
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Match results (per-player per-match)
CREATE TABLE public.match_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  room_code TEXT NOT NULL,
  mode TEXT NOT NULL,
  score INT NOT NULL DEFAULT 0,
  accuracy NUMERIC(5,2) NOT NULL DEFAULT 0,
  avg_reaction_ms INT NOT NULL DEFAULT 0,
  consistency NUMERIC(5,2) NOT NULL DEFAULT 0,
  decision_quality NUMERIC(5,2) NOT NULL DEFAULT 0,
  focus_score INT NOT NULL DEFAULT 0,
  trials_total INT NOT NULL DEFAULT 0,
  trials_correct INT NOT NULL DEFAULT 0,
  team TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_match_results_user ON public.match_results(user_id, created_at DESC);
CREATE INDEX idx_match_results_mode_score ON public.match_results(mode, score DESC);
CREATE INDEX idx_match_results_room ON public.match_results(room_code);
GRANT SELECT, INSERT ON public.match_results TO authenticated;
GRANT SELECT ON public.match_results TO anon;
GRANT ALL ON public.match_results TO service_role;
ALTER TABLE public.match_results ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Results readable by all" ON public.match_results FOR SELECT USING (true);
CREATE POLICY "Users insert own results" ON public.match_results FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
