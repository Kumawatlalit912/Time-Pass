# CogniArena — Multiplayer Cognitive Performance Platform

A Lumosity-meets-esports browser game for teams. Online rooms via Lovable Cloud + Supabase Realtime. Clean "Performance Lab" aesthetic (light, clinical, blue accent #3b82f6).

## v1 Scope (what ships now)

**Auth & profiles**
- Email/password + Google sign-in
- `profiles` table (display name, avatar color, skill tier, total XP)
- `match_results` table (per-player per-round stats for analytics & trends)

**Lobby / rooms**
- Create room → 6-char code, share link
- Join by code, 2–10 players, host picks mode & starts
- Supabase Realtime channel per room for presence, ready-state, round sync, live leaderboard

**3 game modes in v1** (architected so 2 more drop in cleanly later)
1. **Focus Challenge** — sustained-attention CPT. Stream of symbols; tap only targets, ignore distractors. Rewards consistency over speed.
2. **Rapid Decision Arena** — Stroop-style color/word conflicts under time pressure. Measures inhibitory control + reaction time.
3. **Memory Matrix** — flash a grid pattern, recall it. Grid grows with performance (adaptive).

Pattern Recognition & Team Coordination scaffolded with mode registry; stubs marked "coming soon" so users see the roadmap.

**Adaptive difficulty**: each mode tracks rolling accuracy; difficulty (speed/grid size/distractor ratio) adjusts every 3 trials toward ~75% accuracy (flow-state target).

**Scoring** (anti-luck, rewards consistency):
```
roundScore = accuracy * 1000
           + speedBonus (capped, only when accuracy >= 70%)
           + consistencyBonus (1 - stddev(reactionTime)/mean)
           - falsePositivePenalty
```

**Post-game analytics dashboard** per player:
- Focus score (sustained-attention index)
- Avg reaction time + distribution sparkline
- Accuracy %
- Decision quality (correct under conflict / total conflict trials)
- Consistency rating (1 - CV of RT)
- Improvement trend (this session vs. user's 30-day rolling avg)

**Leaderboards**
- Live in-room (realtime channel)
- Global all-time per mode (top 100, from `match_results`)
- Team mode: players tagged with team color, scores summed

**Progression**: XP per match → 6 skill tiers (Rookie → Grandmaster). Achievements: "100% accuracy round", "Sub-300ms avg", "7-day streak".

**Anti-cheat (lightweight, client-side game so realistic limits)**:
- Server-side RT validation (reject < 120ms as anticipation)
- Round seed broadcast from host → all clients run same trials → server compares submitted answers to seed-derived truth
- Rate-limit score submissions per room/round

## Routes

```
/                    landing + CTA
/login               auth (email + Google)
/lobby               create/join room
/room/$code          waiting room + in-game + results
/dashboard           personal stats, trends, achievements
/leaderboard         global rankings per mode
```

## Tech notes (skip if non-technical)

- TanStack Start file routes; `_authenticated` layout guards lobby/dashboard
- Supabase Realtime broadcast channels for game sync (no DB writes during play — only at round end)
- `createServerFn` for score validation & writing `match_results`
- Light tokens already match the Performance Lab palette; small additions for "focus glow" and difficulty bands
- Mode registry: `src/games/modes/{focus,decision,memory}.ts` each export `{ id, name, generateTrial(seed, difficulty), scoreTrial(input) }`

## What's intentionally out of v1

- Pattern Recognition & Team Coordination playable modes (registered but stubbed)
- Tournament brackets (single-room matches only — bracket UI is a v2 addition once mode count grows)
- Mobile-native PWA install (responsive web works on phones; install banner later)

Ready to build this — say go and I'll start with Cloud + auth + lobby, then the 3 modes.