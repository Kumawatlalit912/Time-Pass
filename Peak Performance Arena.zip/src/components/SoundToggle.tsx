import { useEffect, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";
import { isMuted, setMuted, sfx } from "@/lib/sfx";

export function SoundToggle() {
  const [muted, setMutedState] = useState(false);
  useEffect(() => setMutedState(isMuted()), []);
  function toggle() {
    const next = !muted;
    setMuted(next);
    setMutedState(next);
    if (!next) sfx.click();
  }
  return (
    <button
      onClick={toggle}
      className="p-1.5 rounded-md hover:bg-secondary text-muted-foreground hover:text-foreground transition"
      aria-label={muted ? "Unmute sounds" : "Mute sounds"}
      title={muted ? "Unmute" : "Mute"}
    >
      {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
    </button>
  );
}
