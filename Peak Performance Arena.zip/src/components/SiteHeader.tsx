import { Link, useNavigate } from "@tanstack/react-router";
import { Brain, LogOut } from "lucide-react";
import { usePlayer, clearPlayer } from "@/lib/player";
import { SoundToggle } from "@/components/SoundToggle";

export function SiteHeader() {
  const { player, loaded } = usePlayer();
  const navigate = useNavigate();

  function signOut() {
    clearPlayer();
    navigate({ to: "/" });
  }

  return (
    <header className="sticky top-0 z-40 backdrop-blur-md bg-background/80 border-b border-border">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 font-semibold tracking-tight">
          <span className="w-7 h-7 rounded-lg bg-gradient-primary flex items-center justify-center">
            <Brain className="w-4 h-4 text-primary-foreground" />
          </span>
          <span>CogniArena</span>
        </Link>
        <nav className="flex items-center gap-1 text-sm">
          <Link to="/" className="px-3 py-1.5 rounded-md hover:bg-secondary text-muted-foreground hover:text-foreground transition">
            Play
          </Link>
          <SoundToggle />
          {loaded && player && player.name ? (
            <>
              <Link to="/stats" className="px-3 py-1.5 rounded-md hover:bg-secondary text-muted-foreground hover:text-foreground transition">
                My stats
              </Link>
              <div className="flex items-center gap-2 ml-2 pl-3 border-l border-border">
                <span
                  className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold text-white"
                  style={{ backgroundColor: player.color || "#3b82f6" }}
                >
                  {player.name.charAt(0).toUpperCase()}
                </span>
                <span className="text-sm hidden sm:inline">{player.name}</span>
                <button onClick={signOut} className="p-1.5 rounded-md hover:bg-secondary text-muted-foreground" aria-label="Change name">
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </>
          ) : null}
        </nav>
      </div>
    </header>
  );
}
