import type { ModeId } from "./types";

export interface ModeMeta {
  id: ModeId;
  name: string;
  tagline: string;
  description: string;
  trains: string[];
  duration: string;
  available: boolean;
  vibe?: "focus" | "chaos" | "calm";
}

export const MODES: ModeMeta[] = [
  {
    id: "breath",
    name: "Breath Sync",
    tagline: "Lock onto the ring. Tap on every peak.",
    description:
      "A pulsing ring breathes in and out. Tap exactly at full inhale and full exhale. Calm + focus in 45 seconds.",
    trains: ["Rhythm", "Calm focus", "Timing"],
    duration: "~45 sec",
    available: true,
    vibe: "calm",
  },
  {
    id: "tapflow",
    name: "Tap Flow Zone",
    tagline: "Endless targets. Build the combo. Don't break the chain.",
    description:
      "Targets pop everywhere. Tap fast, chain combos, screen shakes harder the deeper you go. Pure flow state.",
    trains: ["Reaction", "Flow", "Combo focus"],
    duration: "~60 sec",
    available: true,
    vibe: "chaos",
  },
  {
    id: "stroop",
    name: "Color Stroop",
    tagline: "Word lies. Color tells truth. Sometimes flipped.",
    description:
      "Pick the COLOR of the text, not the word. Mid-game the rule flips. Inhibition under fire.",
    trains: ["Inhibition", "Attention switch", "Decision"],
    duration: "~50 sec",
    available: true,
    vibe: "focus",
  },
  {
    id: "distract",
    name: "Whack-a-Distraction",
    tagline: "Notifications attack. Swat them. Save your attention.",
    description:
      "Fake notifications keep popping up. Tap to dismiss before they steal your focus. Real ones (✓) — leave alone.",
    trains: ["Focus defense", "Inhibitory control"],
    duration: "~50 sec",
    available: true,
    vibe: "focus",
  },
  {
    id: "focus",
    name: "Focus Challenge",
    tagline: "Sustained attention under a stream of distractors",
    description:
      "Tap only the target symbol. Ignore distractors. Rewards consistency over raw speed.",
    trains: ["Sustained attention", "Inhibition"],
    duration: "~60 sec",
    available: true,
    vibe: "focus",
  },
  {
    id: "decision",
    name: "Rapid Decision Arena",
    tagline: "Stroop-style conflict under time pressure",
    description:
      "The word says one thing, the color says another. Pick the color. Fast.",
    trains: ["Reaction", "Inhibitory control"],
    duration: "~3 min",
    available: true,
    vibe: "focus",
  },
  {
    id: "memory",
    name: "Memory Matrix",
    tagline: "Flash, fade, recall",
    description: "A grid lights up for a moment. Recreate the pattern. The grid grows as you succeed.",
    trains: ["Working memory", "Pattern encoding"],
    duration: "~4 min",
    available: true,
    vibe: "focus",
  },
  {
    id: "reflex",
    name: "Reflex Storm",
    tagline: "5×5 grid. Targets vanish in ms. Traps punish.",
    description: "Targets flash across a grid. Tap green, ignore red. Window shrinks as you survive.",
    trains: ["Reaction time", "Spatial scanning"],
    duration: "~50 sec",
    available: true,
    vibe: "chaos",
  },
  {
    id: "nback",
    name: "N-Back Mayhem",
    tagline: "Did this match the one 2 steps back? Now 3.",
    description: "Hold a sliding window of symbols in mind. MATCH only when the current equals N-back.",
    trains: ["Working memory", "Updating"],
    duration: "~60 sec",
    available: true,
    vibe: "focus",
  },
  {
    id: "chaos",
    name: "Chaos Math",
    tagline: "Speed arithmetic with color-trick distractors.",
    description: "Solve fast. Watch out — colored numbers want to fool you.",
    trains: ["Mental math", "Inhibition"],
    duration: "~50 sec",
    available: true,
    vibe: "chaos",
  },
  {
    id: "schulte",
    name: "Schulte Table",
    tagline: "Find 1 to 25 in order. Peripheral vision drill.",
    description:
      "A 5×5 grid of shuffled numbers. Fix your gaze and tap them in order — the legendary focus and reading-speed trainer.",
    trains: ["Concentration", "Peripheral vision", "Visual search"],
    duration: "~60 sec",
    available: true,
    vibe: "focus",
  },
  {
    id: "echo",
    name: "Echo",
    tagline: "Watch the pads. Repeat the sequence. Each round adds one.",
    description:
      "Simon-style memory game. Pads light up in sequence — you repeat them. The chain grows until you slip.",
    trains: ["Working memory", "Sequencing", "Calm focus"],
    duration: "~60 sec",
    available: true,
    vibe: "calm",
  },
  {
    id: "pattern",
    name: "Pattern Recognition",
    tagline: "Find the rule in the sequence",
    description: "Coming soon.",
    trains: ["Abstract reasoning"],
    duration: "~4 min",
    available: false,
  },
  {
    id: "team",
    name: "Team Coordination",
    tagline: "Sync with your team",
    description: "Coming soon.",
    trains: ["Communication"],
    duration: "~5 min",
    available: false,
  },
];

export function getMode(id: string): ModeMeta | undefined {
  return MODES.find((m) => m.id === id);
}
