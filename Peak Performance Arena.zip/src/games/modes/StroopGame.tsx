import { useEffect, useMemo, useRef, useState } from "react";
import { mulberry32, hashStringToSeed } from "@/lib/seed";
import type { TrialResult } from "@/games/types";
import { sfx } from "@/lib/sfx";

const COLORS = [
  { name: "PINK", hex: "#ff00aa" },
  { name: "CYAN", hex: "#00ffd1" },
  { name: "LIME", hex: "#39ff14" },
  { name: "AMBER", hex: "#ffb300" },
  { name: "VIOLET", hex: "#9b5cff" },
  { name: "RED", hex: "#ff3b00" },
] as const;
const ROUND_MS = 50_000;
const FLIP_AT_MS = 22_000;

interface Props { seed: string; onComplete: (trials: TrialResult[]) => void }

export function StroopGame({ seed, onComplete }: Props) {
  const rng = useMemo(() => mulberry32(hashStringToSeed(seed)), [seed]);
  const [stim, setStim] = useState<{ word: string; ink: typeof COLORS[number]; opts: typeof COLORS[number][] } | null>(null);
  const [rule, setRule] = useState<"COLOR" | "WORD">("COLOR");
  const [timeLeft, setTimeLeft] = useState(ROUND_MS);
  const [flash, setFlash] = useState<"" | "correct" | "wrong">("");
  const trialsRef = useRef<TrialResult[]>([]);
  const startRef = useRef(0);
  const stimStartRef = useRef(0);

  function nextStim() {
    const ink = COLORS[Math.floor(rng() * COLORS.length)];
    const wordObj = COLORS[Math.floor(rng() * COLORS.length)];
    const opts = [...COLORS].sort(() => rng() - 0.5).slice(0, 4);
    const correctOpt = rule === "COLOR" ? ink : wordObj;
    if (!opts.find((o) => o.name === correctOpt.name)) opts[0] = correctOpt;
    stimStartRef.current = performance.now();
    setStim({ word: wordObj.name, ink, opts: opts.sort(() => rng() - 0.5) });
  }

  useEffect(() => {
    startRef.current = performance.now();
    nextStim();
    const t = setInterval(() => {
      const el = performance.now() - startRef.current;
      setTimeLeft(Math.max(0, ROUND_MS - el));
      if (el >= FLIP_AT_MS) setRule("WORD");
      if (el >= ROUND_MS) {
        clearInterval(t);
        onComplete(trialsRef.current);
      }
    }, 120);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function pick(c: typeof COLORS[number]) {
    if (!stim) return;
    const rt = performance.now() - stimStartRef.current;
    const target = rule === "COLOR" ? stim.ink.name : stim.word;
    const correct = c.name === target;
    trialsRef.current.push({ correct, reactionMs: rt, isConflict: stim.ink.name !== stim.word });
    if (correct) sfx.correct(); else sfx.wrong();
    setFlash(correct ? "correct" : "wrong");
    setTimeout(() => setFlash(""), 180);
    nextStim();
  }

  return (
    <div className="flex flex-col items-center gap-6 select-none">
      <div className="text-xs font-mono uppercase tracking-[0.3em] text-accent text-glow">
        pick the {rule}
      </div>
      <div className="font-mono text-xs text-muted-foreground">
        {Math.ceil(timeLeft / 1000)}s · trials {trialsRef.current.length}
        {rule === "WORD" && <span className="ml-2 text-primary text-glow">⚠ RULE FLIPPED</span>}
      </div>
      <div
        className={`w-[420px] h-44 rounded-2xl bg-card/60 neon-border flex items-center justify-center text-7xl font-mono font-bold ${
          flash === "correct" ? "flash-correct" : flash === "wrong" ? "flash-wrong shake" : ""
        }`}
        style={{ color: stim?.ink.hex }}
      >
        {stim?.word}
      </div>
      <div className="grid grid-cols-4 gap-3 w-[420px]">
        {stim?.opts.map((o) => (
          <button
            key={o.name}
            onClick={() => pick(o)}
            className="h-14 rounded-xl font-mono font-bold text-sm border-2 transition active:scale-95"
            style={{ borderColor: o.hex, color: o.hex, boxShadow: `0 0 16px ${o.hex}55` }}
          >
            {o.name}
          </button>
        ))}
      </div>
    </div>
  );
}
