import { useEffect, useRef, useState } from "react";
import type { TrialResult } from "@/games/types";
import { sfx } from "@/lib/sfx";

// Breath Sync: ring expands (inhale) and contracts (exhale) on a 4s cycle.
// Tap when ring is at peak or trough (within tolerance window).
const ROUND_MS = 45_000;
const CYCLE_MS = 4000; // 2s in, 2s out
const TOLERANCE = 280; // ms window around peak/trough

interface Props {
  seed: string;
  onComplete: (trials: TrialResult[]) => void;
}

export function BreathGame({ onComplete }: Props) {
  const [scale, setScale] = useState(0.6);
  const [phase, setPhase] = useState<"INHALE" | "EXHALE">("INHALE");
  const [timeLeft, setTimeLeft] = useState(ROUND_MS);
  const [flash, setFlash] = useState<"" | "correct" | "wrong">("");
  const trialsRef = useRef<TrialResult[]>([]);
  const startRef = useRef(0);
  const lastTapRef = useRef(0);
  const lastHitCycleRef = useRef<number>(-1);

  useEffect(() => {
    startRef.current = performance.now();
    let raf = 0;
    const tick = () => {
      const t = performance.now() - startRef.current;
      if (t >= ROUND_MS) {
        onComplete(trialsRef.current);
        return;
      }
      const c = (t % CYCLE_MS) / CYCLE_MS; // 0..1
      // sinusoidal: 0..0.5 = inhale, 0.5..1 = exhale
      const s = 0.6 + 0.4 * (1 - Math.cos(c * Math.PI * 2)) / 2;
      setScale(s);
      setPhase(c < 0.5 ? "INHALE" : "EXHALE");
      setTimeLeft(ROUND_MS - t);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function tap() {
    const now = performance.now();
    if (now - lastTapRef.current < 200) return;
    lastTapRef.current = now;
    const t = now - startRef.current;
    const cyclePos = t % CYCLE_MS;
    const cycleIdx = Math.floor(t / CYCLE_MS) * 2 + (cyclePos < CYCLE_MS / 2 ? 0 : 1);
    if (cycleIdx === lastHitCycleRef.current) return; // one tap per half-cycle
    // peak at CYCLE_MS/2, trough at 0 or CYCLE_MS
    const distPeak = Math.abs(cyclePos - CYCLE_MS / 2);
    const distTrough = Math.min(cyclePos, CYCLE_MS - cyclePos);
    const dist = Math.min(distPeak, distTrough);
    const correct = dist <= TOLERANCE;
    trialsRef.current.push({ correct, reactionMs: dist });
    lastHitCycleRef.current = cycleIdx;
    if (correct) sfx.pad(); else sfx.wrong();
    setFlash(correct ? "correct" : "wrong");
    setTimeout(() => setFlash(""), 250);
  }

  const ringSize = 280;
  const px = ringSize * scale;

  return (
    <div className="flex flex-col items-center gap-6 select-none">
      <div className="text-xs font-mono uppercase tracking-[0.3em] text-accent text-glow">
        {phase}
      </div>
      <div className="font-mono text-xs text-muted-foreground">
        {Math.ceil(timeLeft / 1000)}s · taps {trialsRef.current.length}
      </div>
      <button
        onClick={tap}
        className={`relative flex items-center justify-center w-[340px] h-[340px] rounded-full bg-card/40 border border-border ${
          flash === "correct" ? "flash-correct" : flash === "wrong" ? "flash-wrong" : ""
        }`}
      >
        <div
          className="rounded-full bg-gradient-arcade transition-none"
          style={{
            width: px,
            height: px,
            boxShadow: `0 0 ${60 * scale}px ${20 * scale}px color-mix(in oklab, var(--primary) ${40 * scale}%, transparent)`,
          }}
        />
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <span className="text-xs font-mono uppercase tracking-widest text-foreground/70">tap on peak / trough</span>
        </div>
      </button>
      <p className="text-xs text-muted-foreground max-w-sm text-center">
        Find the rhythm. Tap when the ring is fully open or fully closed. Slow breathing, sharp focus.
      </p>
    </div>
  );
}
