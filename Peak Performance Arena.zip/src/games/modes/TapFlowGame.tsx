import { useEffect, useRef, useState } from "react";
import type { TrialResult } from "@/games/types";
import { sfx } from "@/lib/sfx";

const ROUND_MS = 60_000;
const W = 560;
const H = 420;

type Target = { id: number; x: number; y: number; r: number; bornAt: number; ttl: number; gold: boolean };

interface Props { seed: string; onComplete: (trials: TrialResult[]) => void }

export function TapFlowGame({ onComplete }: Props) {
  const [targets, setTargets] = useState<Target[]>([]);
  const [combo, setCombo] = useState(0);
  const [bestCombo, setBestCombo] = useState(0);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(ROUND_MS);
  const [shake, setShake] = useState("");
  const [pops, setPops] = useState<{ id: number; x: number; y: number; text: string; color: string }[]>([]);
  const trialsRef = useRef<TrialResult[]>([]);
  const idRef = useRef(0);
  const ttlRef = useRef(1300);

  useEffect(() => {
    const start = performance.now();
    let stopped = false;

    const tick = setInterval(() => {
      if (stopped) return;
      const now = performance.now();
      const el = now - start;
      setTimeLeft(Math.max(0, ROUND_MS - el));
      if (el >= ROUND_MS) {
        stopped = true;
        clearInterval(tick);
        clearInterval(spawner);
        onComplete(trialsRef.current);
        return;
      }
      ttlRef.current = Math.max(550, 1300 - Math.floor(el / 4000) * 90);
      setTargets((prev) => {
        const live: Target[] = [];
        for (const t of prev) {
          if (now - t.bornAt > t.ttl) {
            trialsRef.current.push({ correct: false, reactionMs: t.ttl });
            setCombo(0);
          } else live.push(t);
        }
        return live;
      });
    }, 90);

    const spawner = setInterval(() => {
      if (stopped) return;
      setTargets((prev) => {
        if (prev.length >= 4) return prev;
        const burst = Math.random() < 0.3 ? 2 : 1;
        const next = [...prev];
        for (let i = 0; i < burst; i++) {
          next.push({
            id: idRef.current++,
            x: 40 + Math.random() * (W - 80),
            y: 40 + Math.random() * (H - 80),
            r: 28 + Math.random() * 18,
            bornAt: performance.now(),
            ttl: ttlRef.current,
            gold: Math.random() < 0.12,
          });
        }
        return next;
      });
    }, 420);

    return () => {
      stopped = true;
      clearInterval(tick);
      clearInterval(spawner);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function hit(t: Target, e: React.MouseEvent) {
    e.stopPropagation();
    const rt = performance.now() - t.bornAt;
    trialsRef.current.push({ correct: true, reactionMs: rt });
    if (t.gold) sfx.win(); else sfx.pop();
    setCombo((c) => {
      const nc = c + 1;
      setBestCombo((b) => Math.max(b, nc));
      if (nc % 10 === 0) {
        setShake("shake-hard");
        sfx.combo();
        setTimeout(() => setShake(""), 450);
      } else if (nc % 5 === 0) {
        setShake("shake");
        sfx.combo();
        setTimeout(() => setShake(""), 350);
      }
      const mult = 1 + Math.floor(nc / 5) * 0.5;
      const base = t.gold ? 50 : 10;
      const gained = Math.round(base * mult);
      setScore((s) => s + gained);
      setPops((p) => [
        ...p,
        { id: idRef.current++, x: t.x, y: t.y, text: `+${gained}${t.gold ? " ★" : ""}`, color: t.gold ? "#ffeb00" : "#00ffd1" },
      ]);
      return nc;
    });
    setTargets((prev) => prev.filter((x) => x.id !== t.id));
    setTimeout(() => setPops((p) => p.slice(-12)), 700);
  }

  function missClick() {
    setCombo(0);
    sfx.wrong();
    setShake("shake");
    setTimeout(() => setShake(""), 350);
  }

  return (
    <div className="flex flex-col items-center gap-3 select-none">
      <div className="flex items-center gap-6 font-mono text-sm">
        <div>⏱ <span className="text-accent">{Math.ceil(timeLeft / 1000)}s</span></div>
        <div>SCORE <span className="text-primary text-glow font-bold">{score}</span></div>
        <div>COMBO <span className={combo >= 10 ? "text-warning text-glow text-xl" : "text-foreground"}>×{combo}</span></div>
        <div className="text-muted-foreground">best ×{bestCombo}</div>
      </div>
      <div
        onClick={missClick}
        className={`relative overflow-hidden rounded-2xl bg-card/40 neon-border ${shake}`}
        style={{ width: W, height: H, backgroundImage: "radial-gradient(circle at 30% 30%, rgba(255,0,170,0.08), transparent 60%), radial-gradient(circle at 70% 70%, rgba(0,255,209,0.08), transparent 60%)" }}
      >
        {targets.map((t) => {
          const age = (performance.now() - t.bornAt) / t.ttl;
          const opacity = age < 0.2 ? age / 0.2 : 1 - Math.max(0, (age - 0.7) / 0.3);
          return (
            <button
              key={t.id}
              onClick={(e) => hit(t, e)}
              className="absolute rounded-full border-2"
              style={{
                left: t.x - t.r,
                top: t.y - t.r,
                width: t.r * 2,
                height: t.r * 2,
                background: t.gold ? "radial-gradient(circle, #ffeb00, #ff8a3d)" : "radial-gradient(circle, #ff00aa, #9b5cff)",
                borderColor: t.gold ? "#ffeb00" : "#00ffd1",
                boxShadow: t.gold ? "0 0 32px #ffeb0099" : "0 0 24px #ff00aa99",
                opacity,
              }}
            />
          );
        })}
        {pops.map((p) => (
          <div
            key={p.id}
            className="absolute font-mono font-bold text-sm pointer-events-none float-up"
            style={{ left: p.x, top: p.y, color: p.color, textShadow: `0 0 12px ${p.color}` }}
          >
            {p.text}
          </div>
        ))}
      </div>
      <p className="text-xs text-muted-foreground max-w-sm text-center">
        Tap the orbs. Build the chain. Gold = 5×. Missing or clicking empty space breaks combo.
      </p>
    </div>
  );
}
