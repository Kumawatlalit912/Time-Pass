import { useMemo, useRef, useState } from "react";
import type { TrialResult } from "@/games/types";
import { sfx } from "@/lib/sfx";

// Schulte Table: tap numbers 1..25 in order on a 5x5 grid as fast as possible.
// Classic concentration / peripheral-vision trainer. Each correct tap = 1 trial.

const SIZE = 25;

function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6D2B79F5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashSeed(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

function shuffle<T>(arr: T[], rng: () => number) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

interface Props {
  seed: string;
  onComplete: (trials: TrialResult[]) => void;
}

export function SchulteGame({ seed, onComplete }: Props) {
  const layout = useMemo(() => {
    const rng = mulberry32(hashSeed(seed));
    return shuffle(Array.from({ length: SIZE }, (_, i) => i + 1), rng);
  }, [seed]);

  const [next, setNext] = useState(1);
  const [flashIdx, setFlashIdx] = useState<number | null>(null);
  const [wrongIdx, setWrongIdx] = useState<number | null>(null);
  const startRef = useRef(performance.now());
  const lastTapRef = useRef(performance.now());
  const trialsRef = useRef<TrialResult[]>([]);

  function tap(num: number, idx: number) {
    const now = performance.now();
    const rt = now - lastTapRef.current;
    const correct = num === next;
    trialsRef.current.push({ correct, reactionMs: rt });
    if (correct) {
      lastTapRef.current = now;
      setFlashIdx(idx);
      setTimeout(() => setFlashIdx(null), 200);
      if (next === SIZE) {
        sfx.win();
        onComplete(trialsRef.current);
        return;
      }
      sfx.tap();
      setNext(next + 1);
    } else {
      sfx.wrong();
      setWrongIdx(idx);
      setTimeout(() => setWrongIdx(null), 200);
    }
  }

  const elapsed = ((performance.now() - startRef.current) / 1000).toFixed(1);

  return (
    <div className="flex flex-col items-center gap-5 select-none">
      <div className="flex items-center gap-6 text-xs font-mono uppercase tracking-[0.25em] text-muted-foreground">
        <span>Next: <span className="text-accent text-base">{next}</span></span>
        <span>Progress: {next - 1}/{SIZE}</span>
      </div>
      <div className="grid grid-cols-5 gap-2">
        {layout.map((n, i) => (
          <button
            key={i}
            onClick={() => tap(n, i)}
            className={`w-16 h-16 md:w-20 md:h-20 rounded-xl border border-border bg-card text-xl md:text-2xl font-mono font-semibold transition-colors
              ${flashIdx === i ? "bg-success/40" : ""}
              ${wrongIdx === i ? "bg-destructive/40" : ""}
              hover:bg-secondary`}
          >
            {n}
          </button>
        ))}
      </div>
      <p className="text-xs text-muted-foreground max-w-sm text-center">
        Fix your gaze near the center. Find 1, 2, 3… in order using peripheral vision. Time: {elapsed}s
      </p>
    </div>
  );
}
