import { useEffect, useMemo, useRef, useState } from "react";
import { mulberry32, hashStringToSeed, pick } from "@/lib/seed";
import type { TrialResult } from "@/games/types";
import { sfx } from "@/lib/sfx";

// N-Back Mayhem: a symbol appears every ~1.5s. Tap MATCH if it equals the one
// from N steps ago. Starts at 2-back, escalates to 3-back at 30s.

const SYMBOLS = ["A", "B", "C", "D", "E", "F", "G", "H"] as const;
const ROUND_MS = 60_000;
const STEP_MS = 1700;

interface Props {
  seed: string;
  onComplete: (trials: TrialResult[]) => void;
}

export function NBackGame({ seed, onComplete }: Props) {
  const rng = useMemo(() => mulberry32(hashStringToSeed(seed)), [seed]);
  const [current, setCurrent] = useState<string>("");
  const [timeLeft, setTimeLeft] = useState(ROUND_MS);
  const [n, setN] = useState(2);
  const [flash, setFlash] = useState<"" | "correct" | "wrong">("");
  const historyRef = useRef<string[]>([]);
  const trialsRef = useRef<TrialResult[]>([]);
  const stepStartRef = useRef(0);
  const isMatchRef = useRef(false);
  const answeredRef = useRef(false);
  const nRef = useRef(2);

  useEffect(() => {
    let stopped = false;
    const start = performance.now();

    function nextStep() {
      if (stopped) return;
      const elapsed = performance.now() - start;
      setTimeLeft(Math.max(0, ROUND_MS - elapsed));
      if (elapsed >= ROUND_MS) {
        stopped = true;
        onComplete(trialsRef.current);
        return;
      }
      if (elapsed > 30_000 && nRef.current < 3) {
        nRef.current = 3;
        setN(3);
      }

      // If previous step wasn't answered, score it
      if (historyRef.current.length > nRef.current && !answeredRef.current) {
        trialsRef.current.push({
          correct: !isMatchRef.current, // no-press = correct only if it wasn't a match
          reactionMs: STEP_MS,
          isConflict: isMatchRef.current,
        });
      }

      // Choose next symbol: 33% force a match if possible
      const N = nRef.current;
      let sym: string;
      const canMatch = historyRef.current.length >= N;
      if (canMatch && rng() < 0.34) {
        sym = historyRef.current[historyRef.current.length - N];
        isMatchRef.current = true;
      } else {
        const target = canMatch ? historyRef.current[historyRef.current.length - N] : "";
        sym = pick(rng, SYMBOLS.filter((s) => s !== target));
        isMatchRef.current = false;
      }
      historyRef.current.push(sym);
      answeredRef.current = false;
      stepStartRef.current = performance.now();
      setCurrent(sym);
    }

    nextStep();
    const i = setInterval(nextStep, STEP_MS);
    return () => {
      stopped = true;
      clearInterval(i);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function press() {
    if (answeredRef.current || historyRef.current.length <= nRef.current) return;
    answeredRef.current = true;
    const rt = performance.now() - stepStartRef.current;
    const correct = isMatchRef.current;
    trialsRef.current.push({ correct, reactionMs: rt, isConflict: true });
    if (correct) sfx.correct(); else sfx.wrong();
    setFlash(correct ? "correct" : "wrong");
    setTimeout(() => setFlash(""), 200);
  }

  return (
    <div className="flex flex-col items-center gap-6 select-none">
      <div className="text-sm text-muted-foreground">
        Press MATCH if symbol equals the one <span className="text-primary font-semibold">{n}</span> steps back
      </div>
      <div className="font-mono text-xs text-muted-foreground">
        {Math.ceil(timeLeft / 1000)}s · {n}-back · trials {trialsRef.current.length}
      </div>
      <div
        className={`w-64 h-64 rounded-2xl bg-card border-2 border-border flex items-center justify-center text-9xl font-mono shadow-elegant ${
          flash === "correct" ? "flash-correct" : flash === "wrong" ? "flash-wrong" : ""
        }`}
      >
        {current || <span className="text-muted-foreground/30 text-xl">…</span>}
      </div>
      <button
        onClick={press}
        className="w-64 h-14 rounded-xl bg-primary text-primary-foreground font-bold text-lg active:scale-95 transition"
      >
        MATCH
      </button>
      <p className="text-xs text-muted-foreground max-w-sm text-center">
        Stay silent on non-matches. Memory under speed. Difficulty escalates.
      </p>
    </div>
  );
}
