import { useEffect, useMemo, useRef, useState } from "react";
import { mulberry32, hashStringToSeed, pick } from "@/lib/seed";
import type { TrialResult } from "@/games/types";
import { sfx } from "@/lib/sfx";

const COLORS = [
  { name: "RED", hex: "#ef4444" },
  { name: "BLUE", hex: "#3b82f6" },
  { name: "GREEN", hex: "#10b981" },
  { name: "YELLOW", hex: "#f59e0b" },
] as const;
const ROUND_MS = 60_000;

interface Props {
  seed: string;
  onComplete: (trials: TrialResult[]) => void;
}

export function DecisionGame({ seed, onComplete }: Props) {
  const rng = useMemo(() => mulberry32(hashStringToSeed(seed)), [seed]);
  const [trial, setTrial] = useState<{ word: typeof COLORS[number]; ink: typeof COLORS[number]; isConflict: boolean } | null>(null);
  const [timeLeft, setTimeLeft] = useState(ROUND_MS);
  const [flash, setFlash] = useState<"" | "correct" | "wrong">("");
  const trialsRef = useRef<TrialResult[]>([]);
  const startRef = useRef(0);
  const answeredRef = useRef(false);
  const windowRef = useRef(2400);

  useEffect(() => {
    let stopped = false;
    const t0 = performance.now();

    function next() {
      if (stopped) return;
      const elapsed = performance.now() - t0;
      if (elapsed >= ROUND_MS) {
        stopped = true;
        onComplete(trialsRef.current);
        return;
      }
      setTimeLeft(Math.max(0, ROUND_MS - elapsed));

      const recent = trialsRef.current.slice(-5);
      if (recent.length === 5) {
        const acc = recent.filter((t) => t.correct).length / 5;
        if (acc > 0.85) windowRef.current = Math.max(800, windowRef.current - 150);
        else if (acc < 0.6) windowRef.current = Math.min(3000, windowRef.current + 150);
      }

      const word = pick(rng, COLORS);
      // 60% conflict trials
      const isConflict = rng() < 0.6;
      const ink = isConflict
        ? pick(rng, COLORS.filter((c) => c.name !== word.name))
        : word;

      answeredRef.current = false;
      startRef.current = performance.now();
      setTrial({ word, ink, isConflict });

      setTimeout(() => {
        if (stopped) return;
        if (!answeredRef.current) {
          trialsRef.current.push({ correct: false, reactionMs: windowRef.current, isConflict });
        }
        setTimeout(next, 200);
      }, windowRef.current);
    }

    next();
    return () => {
      stopped = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function answer(colorName: string) {
    if (!trial || answeredRef.current) return;
    answeredRef.current = true;
    const correct = trial.ink.name === colorName;
    const rt = performance.now() - startRef.current;
    trialsRef.current.push({ correct, reactionMs: rt, isConflict: trial.isConflict });
    if (correct) sfx.correct(); else sfx.wrong();
    setFlash(correct ? "correct" : "wrong");
    setTimeout(() => setFlash(""), 200);
    setTrial(null);
  }

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="text-sm text-muted-foreground">
        Pick the <span className="text-foreground font-semibold">color of the ink</span>, not the word.
      </div>
      <div className="font-mono text-xs text-muted-foreground">
        {Math.ceil(timeLeft / 1000)}s · trials {trialsRef.current.length}
      </div>
      <div
        className={`w-80 h-40 rounded-2xl bg-card border-2 border-border flex items-center justify-center shadow-elegant ${
          flash === "correct" ? "flash-correct" : flash === "wrong" ? "flash-wrong" : ""
        }`}
      >
        {trial ? (
          <span className="text-6xl font-bold tracking-wider" style={{ color: trial.ink.hex }}>
            {trial.word.name}
          </span>
        ) : (
          <span className="text-muted-foreground/30">…</span>
        )}
      </div>
      <div className="grid grid-cols-4 gap-3 w-full max-w-md">
        {COLORS.map((c) => (
          <button
            key={c.name}
            onClick={() => answer(c.name)}
            className="h-14 rounded-xl font-semibold text-white shadow-sm active:scale-95 transition"
            style={{ backgroundColor: c.hex }}
          >
            {c.name}
          </button>
        ))}
      </div>
    </div>
  );
}
