import { useEffect, useRef, useState } from "react";
import type { TrialResult } from "@/games/types";
import { sfx } from "@/lib/sfx";

// Reflex Storm: targets pop up across a 5x5 grid. Tap green ones, avoid red.
// Multiple can appear at once. Window shrinks as you go. Brutal.

const COLS = 5;
const ROWS = 5;
const ROUND_MS = 50_000;

type Cell = {
  id: number;
  pos: number;
  kind: "target" | "trap";
  bornAt: number;
  ttl: number;
};

interface Props {
  seed: string;
  onComplete: (trials: TrialResult[]) => void;
}

export function ReflexGame({ onComplete }: Props) {
  const [cells, setCells] = useState<Cell[]>([]);
  const [timeLeft, setTimeLeft] = useState(ROUND_MS);
  const [flash, setFlash] = useState<"" | "correct" | "wrong">("");
  const trialsRef = useRef<TrialResult[]>([]);
  const ttlRef = useRef(1100);
  const spawnEveryRef = useRef(700);
  const idRef = useRef(0);

  useEffect(() => {
    let stopped = false;
    const start = performance.now();

    const tick = setInterval(() => {
      if (stopped) return;
      const now = performance.now();
      const elapsed = now - start;
      setTimeLeft(Math.max(0, ROUND_MS - elapsed));
      if (elapsed >= ROUND_MS) {
        stopped = true;
        clearInterval(tick);
        clearInterval(spawner);
        onComplete(trialsRef.current);
        return;
      }
      // expire missed cells = miss penalty for targets
      setCells((prev) => {
        const live: Cell[] = [];
        for (const c of prev) {
          if (now - c.bornAt > c.ttl) {
            if (c.kind === "target") {
              trialsRef.current.push({ correct: false, reactionMs: c.ttl });
            } else {
              // ignored a trap = correct no-go
              trialsRef.current.push({ correct: true, reactionMs: c.ttl });
            }
          } else live.push(c);
        }
        return live;
      });
      // ramp difficulty every 5s
      ttlRef.current = Math.max(420, 1100 - Math.floor(elapsed / 5000) * 80);
      spawnEveryRef.current = Math.max(220, 700 - Math.floor(elapsed / 5000) * 50);
    }, 100);

    const spawner = setInterval(() => {
      if (stopped) return;
      setCells((prev) => {
        const occupied = new Set(prev.map((c) => c.pos));
        const free: number[] = [];
        for (let i = 0; i < COLS * ROWS; i++) if (!occupied.has(i)) free.push(i);
        if (!free.length) return prev;
        const burst = Math.random() < 0.25 ? 2 : 1;
        const next = [...prev];
        for (let b = 0; b < burst && free.length; b++) {
          const pos = free.splice(Math.floor(Math.random() * free.length), 1)[0];
          next.push({
            id: idRef.current++,
            pos,
            kind: Math.random() < 0.28 ? "trap" : "target",
            bornAt: performance.now(),
            ttl: ttlRef.current,
          });
        }
        return next;
      });
    }, spawnEveryRef.current);

    return () => {
      stopped = true;
      clearInterval(tick);
      clearInterval(spawner);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function tapCell(c: Cell) {
    const rt = performance.now() - c.bornAt;
    const correct = c.kind === "target";
    trialsRef.current.push({ correct, reactionMs: rt });
    if (correct) sfx.pop(); else sfx.wrong();
    setFlash(correct ? "correct" : "wrong");
    setTimeout(() => setFlash(""), 150);
    setCells((prev) => prev.filter((x) => x.id !== c.id));
  }

  return (
    <div className="flex flex-col items-center gap-4 select-none">
      <div className="text-sm text-muted-foreground">
        Tap <span className="text-success font-semibold">GREEN</span> · ignore <span className="text-destructive font-semibold">RED</span>
      </div>
      <div className="font-mono text-xs text-muted-foreground">
        {Math.ceil(timeLeft / 1000)}s · ttl {ttlRef.current}ms · trials {trialsRef.current.length}
      </div>
      <div
        className={`grid gap-2 p-3 rounded-2xl bg-card border-2 border-border shadow-elegant ${
          flash === "correct" ? "flash-correct" : flash === "wrong" ? "flash-wrong" : ""
        }`}
        style={{ gridTemplateColumns: `repeat(${COLS}, 64px)` }}
      >
        {Array.from({ length: COLS * ROWS }).map((_, i) => {
          const c = cells.find((x) => x.pos === i);
          return (
            <button
              key={i}
              onClick={() => c && tapCell(c)}
              className={`w-16 h-16 rounded-lg border transition-all duration-100 ${
                c
                  ? c.kind === "target"
                    ? "bg-success border-success scale-100 shadow-md"
                    : "bg-destructive border-destructive scale-100 shadow-md"
                  : "bg-muted/40 border-border/40"
              }`}
              aria-label={c?.kind ?? "empty"}
            />
          );
        })}
      </div>
      <p className="text-xs text-muted-foreground max-w-sm text-center">
        Targets vanish fast. Hitting traps stings. Speed × restraint = score.
      </p>
    </div>
  );
}
