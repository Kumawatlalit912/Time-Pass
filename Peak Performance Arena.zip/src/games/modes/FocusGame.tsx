import { useEffect, useMemo, useRef, useState } from "react";
import { mulberry32, hashStringToSeed, pick } from "@/lib/seed";
import type { TrialResult } from "@/games/types";
import { sfx } from "@/lib/sfx";

const SYMBOLS = ["◆", "●", "▲", "■", "★", "✚"] as const;
const ROUND_MS = 60_000; // 60s per round
const STIM_BASE_MS = 1200;

type Stim = { sym: string; isTarget: boolean; idx: number };

interface Props {
  seed: string;
  onComplete: (trials: TrialResult[]) => void;
}

export function FocusGame({ seed, onComplete }: Props) {
  const rng = useMemo(() => mulberry32(hashStringToSeed(seed)), [seed]);
  const target = useMemo(() => pick(rng, SYMBOLS), [rng]);
  const [stim, setStim] = useState<Stim | null>(null);
  const [timeLeft, setTimeLeft] = useState(ROUND_MS);
  const [flash, setFlash] = useState<"" | "correct" | "wrong">("");
  const trialsRef = useRef<TrialResult[]>([]);
  const stimStartRef = useRef<number>(0);
  const answeredRef = useRef<boolean>(false);
  const idxRef = useRef(0);
  const difficultyRef = useRef(STIM_BASE_MS);

  useEffect(() => {
    let stopped = false;
    const startTs = performance.now();

    function next() {
      if (stopped) return;
      const elapsed = performance.now() - startTs;
      if (elapsed >= ROUND_MS) {
        finish();
        return;
      }
      setTimeLeft(Math.max(0, ROUND_MS - elapsed));

      // adaptive: every 5 trials, adjust difficulty toward 75% accuracy
      const recent = trialsRef.current.slice(-5);
      if (recent.length === 5) {
        const acc = recent.filter((t) => t.correct).length / 5;
        if (acc > 0.85) difficultyRef.current = Math.max(450, difficultyRef.current - 80);
        else if (acc < 0.6) difficultyRef.current = Math.min(1600, difficultyRef.current + 80);
      }

      const isTarget = rng() < 0.4;
      const sym = isTarget ? target : pick(rng, SYMBOLS.filter((s) => s !== target));
      const idx = idxRef.current++;
      answeredRef.current = false;
      stimStartRef.current = performance.now();
      setStim({ sym, isTarget, idx });

      const window = difficultyRef.current;
      setTimeout(() => {
        if (stopped) return;
        if (!answeredRef.current) {
          // missed
          trialsRef.current.push({
            correct: !isTarget, // ignoring a distractor = correct (no-go)
            reactionMs: window,
          });
        }
        setStim(null);
        setTimeout(next, 250);
      }, window);
    }

    function finish() {
      stopped = true;
      onComplete(trialsRef.current);
    }

    next();
    const t = setInterval(() => {
      setTimeLeft((ms) => Math.max(0, ms - 100));
    }, 100);
    return () => {
      stopped = true;
      clearInterval(t);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function tap() {
    if (!stim || answeredRef.current) return;
    answeredRef.current = true;
    const rt = performance.now() - stimStartRef.current;
    const correct = stim.isTarget;
    trialsRef.current.push({ correct, reactionMs: rt });
    if (correct) sfx.correct(); else sfx.wrong();
    setFlash(correct ? "correct" : "wrong");
    setTimeout(() => setFlash(""), 300);
  }

  return (
    <div className="flex flex-col items-center gap-6 select-none">
      <div className="text-sm text-muted-foreground">
        Tap when you see <span className="font-mono text-2xl text-primary">{target}</span>
      </div>
      <div className="font-mono text-xs text-muted-foreground">
        {Math.ceil(timeLeft / 1000)}s left · trials {trialsRef.current.length}
      </div>
      <button
        onClick={tap}
        className={`relative w-72 h-72 rounded-2xl bg-card border-2 border-border flex items-center justify-center text-8xl font-mono shadow-elegant active:scale-[0.98] transition ${
          flash === "correct" ? "flash-correct" : flash === "wrong" ? "flash-wrong" : ""
        }`}
      >
        {stim ? stim.sym : <span className="text-muted-foreground/30 text-xl">…</span>}
      </button>
      <p className="text-xs text-muted-foreground max-w-sm text-center">
        Tap only on the target. Ignore everything else. Consistency beats speed.
      </p>
    </div>
  );
}
