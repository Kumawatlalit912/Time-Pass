import { useEffect, useMemo, useRef, useState } from "react";
import { mulberry32, hashStringToSeed } from "@/lib/seed";
import type { TrialResult } from "@/games/types";
import { sfx } from "@/lib/sfx";

interface Props {
  seed: string;
  onComplete: (trials: TrialResult[]) => void;
}

type Phase = "show" | "input" | "feedback";

const TOTAL_TRIALS = 10;

export function MemoryGame({ seed, onComplete }: Props) {
  const rng = useMemo(() => mulberry32(hashStringToSeed(seed)), [seed]);
  const [size, setSize] = useState(3);
  const [pattern, setPattern] = useState<Set<number>>(new Set());
  const [picked, setPicked] = useState<Set<number>>(new Set());
  const [phase, setPhase] = useState<Phase>("show");
  const [trialIdx, setTrialIdx] = useState(0);
  const trialsRef = useRef<TrialResult[]>([]);
  const startRef = useRef(0);

  useEffect(() => {
    if (trialIdx >= TOTAL_TRIALS) {
      onComplete(trialsRef.current);
      return;
    }
    // build pattern
    const n = size * size;
    const cellsToLight = Math.min(n - 1, Math.max(3, Math.floor(size * 1.5)));
    const set = new Set<number>();
    while (set.size < cellsToLight) set.add(Math.floor(rng() * n));
    setPattern(set);
    setPicked(new Set());
    setPhase("show");

    const showMs = Math.max(900, 2200 - size * 200);
    const tShow = setTimeout(() => {
      setPhase("input");
      startRef.current = performance.now();
    }, showMs);
    return () => clearTimeout(tShow);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [trialIdx, size]);

  function toggle(i: number) {
    if (phase !== "input") return;
    const np = new Set(picked);
    if (np.has(i)) np.delete(i); else np.add(i);
    sfx.tap();
    setPicked(np);
  }

  function submit() {
    if (phase !== "input") return;
    const rt = performance.now() - startRef.current;
    let allRight = picked.size === pattern.size;
    if (allRight) for (const i of picked) if (!pattern.has(i)) { allRight = false; break; }
    trialsRef.current.push({ correct: allRight, reactionMs: rt, isConflict: size >= 4 });
    if (allRight) sfx.correct(); else sfx.wrong();
    setPhase("feedback");
    // adapt size
    const recent = trialsRef.current.slice(-3);
    if (recent.length === 3) {
      const acc = recent.filter((t) => t.correct).length / 3;
      if (acc >= 0.8) setSize((s) => Math.min(6, s + 1));
      else if (acc <= 0.4) setSize((s) => Math.max(3, s - 1));
    }
    setTimeout(() => setTrialIdx((i) => i + 1), 700);
  }

  const cells: number[] = [];
  for (let i = 0; i < size * size; i++) cells.push(i);

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="text-sm text-muted-foreground">
        {phase === "show"
          ? "Memorize the lit cells…"
          : phase === "input"
            ? "Tap the cells you remember, then submit."
            : "—"}
      </div>
      <div className="font-mono text-xs text-muted-foreground">
        Trial {Math.min(trialIdx + 1, TOTAL_TRIALS)} / {TOTAL_TRIALS} · grid {size}×{size}
      </div>
      <div
        className="grid gap-2 p-3 bg-card border-2 border-border rounded-2xl shadow-elegant"
        style={{ gridTemplateColumns: `repeat(${size}, minmax(0, 1fr))` }}
      >
        {cells.map((i) => {
          const lit = phase === "show" ? pattern.has(i) : phase === "feedback"
            ? pattern.has(i)
            : picked.has(i);
          const wrong = phase === "feedback" && picked.has(i) && !pattern.has(i);
          return (
            <button
              key={i}
              onClick={() => toggle(i)}
              disabled={phase !== "input"}
              className={`w-14 h-14 rounded-lg border transition ${
                wrong
                  ? "bg-destructive border-destructive"
                  : lit
                    ? "bg-primary border-primary"
                    : "bg-secondary border-border"
              }`}
            />
          );
        })}
      </div>
      <button
        onClick={submit}
        disabled={phase !== "input"}
        className="px-6 py-2 rounded-lg bg-primary text-primary-foreground font-medium disabled:opacity-40"
      >
        Submit
      </button>
    </div>
  );
}
