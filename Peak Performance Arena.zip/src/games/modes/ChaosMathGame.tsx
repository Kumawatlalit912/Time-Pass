import { useEffect, useMemo, useRef, useState } from "react";
import { mulberry32, hashStringToSeed } from "@/lib/seed";
import type { TrialResult } from "@/games/types";
import { sfx } from "@/lib/sfx";

// Chaos Math: rapid arithmetic with shrinking time per question.
// 4 answer buttons, positions shuffle, occasional "trick" question with
// a color/word conflict to test inhibition.

const ROUND_MS = 50_000;

type Q = {
  text: string;
  answer: number;
  options: number[];
  startedAt: number;
  ttl: number;
  isConflict: boolean;
  conflictColor?: string;
};

interface Props {
  seed: string;
  onComplete: (trials: TrialResult[]) => void;
}

function genQuestion(rng: () => number, ttl: number): Q {
  const ops = ["+", "-", "×"] as const;
  const op = ops[Math.floor(rng() * ops.length)];
  let a = 2 + Math.floor(rng() * 18);
  let b = 2 + Math.floor(rng() * 12);
  let answer = 0;
  if (op === "+") answer = a + b;
  else if (op === "-") { if (b > a) [a, b] = [b, a]; answer = a - b; }
  else answer = a * b;
  const optsSet = new Set<number>([answer]);
  while (optsSet.size < 4) {
    const delta = (Math.floor(rng() * 9) - 4) || 1;
    const candidate = answer + delta;
    if (candidate >= 0) optsSet.add(candidate);
  }
  const options = Array.from(optsSet).sort(() => rng() - 0.5);
  const isConflict = rng() < 0.25;
  return {
    text: `${a} ${op} ${b}`,
    answer,
    options,
    startedAt: performance.now(),
    ttl,
    isConflict,
    conflictColor: isConflict ? (rng() < 0.5 ? "text-destructive" : "text-success") : undefined,
  };
}

export function ChaosMathGame({ seed, onComplete }: Props) {
  const rng = useMemo(() => mulberry32(hashStringToSeed(seed)), [seed]);
  const [q, setQ] = useState<Q | null>(null);
  const [timeLeft, setTimeLeft] = useState(ROUND_MS);
  const [flash, setFlash] = useState<"" | "correct" | "wrong">("");
  const trialsRef = useRef<TrialResult[]>([]);
  const ttlRef = useRef(4500);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    let stopped = false;
    const start = performance.now();

    function next() {
      if (stopped) return;
      const elapsed = performance.now() - start;
      setTimeLeft(Math.max(0, ROUND_MS - elapsed));
      if (elapsed >= ROUND_MS) {
        stopped = true;
        onComplete(trialsRef.current);
        return;
      }
      ttlRef.current = Math.max(1400, 4500 - Math.floor(elapsed / 5000) * 350);
      const nq = genQuestion(rng, ttlRef.current);
      setQ(nq);
      timerRef.current = setTimeout(() => {
        if (stopped) return;
        trialsRef.current.push({ correct: false, reactionMs: nq.ttl, isConflict: nq.isConflict });
        next();
      }, nq.ttl);
    }

    next();
    return () => {
      stopped = true;
      if (timerRef.current) clearTimeout(timerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function answer(v: number) {
    if (!q) return;
    if (timerRef.current) clearTimeout(timerRef.current);
    const rt = performance.now() - q.startedAt;
    const correct = v === q.answer;
    trialsRef.current.push({ correct, reactionMs: rt, isConflict: q.isConflict });
    if (correct) sfx.correct(); else sfx.wrong();
    setFlash(correct ? "correct" : "wrong");
    setTimeout(() => setFlash(""), 150);
    // small gap then next
    setTimeout(() => {
      const elapsed = performance.now() - performance.timeOrigin;
      void elapsed;
      // continue loop
      const startNew = () => {
        const nq = genQuestion(rng, ttlRef.current);
        setQ(nq);
        timerRef.current = setTimeout(() => {
          trialsRef.current.push({ correct: false, reactionMs: nq.ttl, isConflict: nq.isConflict });
          startNew();
        }, nq.ttl);
      };
      startNew();
    }, 120);
  }

  return (
    <div className="flex flex-col items-center gap-6 select-none">
      <div className="text-sm text-muted-foreground">Solve. Fast. Don't get tricked.</div>
      <div className="font-mono text-xs text-muted-foreground">
        {Math.ceil(timeLeft / 1000)}s · ttl {ttlRef.current}ms · trials {trialsRef.current.length}
      </div>
      <div
        className={`w-80 h-40 rounded-2xl bg-card border-2 border-border flex items-center justify-center shadow-elegant ${
          flash === "correct" ? "flash-correct" : flash === "wrong" ? "flash-wrong" : ""
        }`}
      >
        <div className={`text-6xl font-mono font-bold ${q?.conflictColor ?? ""}`}>
          {q ? q.text : "…"}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3 w-80">
        {q?.options.map((o) => (
          <button
            key={o}
            onClick={() => answer(o)}
            className="h-16 rounded-xl border-2 border-border bg-background hover:border-primary text-2xl font-mono font-bold active:scale-95 transition"
          >
            {o}
          </button>
        ))}
      </div>
      <p className="text-xs text-muted-foreground max-w-sm text-center">
        Colored numbers are a trap — read the math, ignore the color.
      </p>
    </div>
  );
}
