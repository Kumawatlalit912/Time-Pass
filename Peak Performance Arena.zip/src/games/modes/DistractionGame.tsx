import { useEffect, useRef, useState } from "react";
import type { TrialResult } from "@/games/types";
import { sfx } from "@/lib/sfx";

const ROUND_MS = 50_000;
const W = 560;
const H = 420;

const FAKE = [
  { app: "Instagram", text: "5 new likes on your story", color: "#ff00aa" },
  { app: "TikTok", text: "FYP is calling…", color: "#00ffd1" },
  { app: "Slack", text: "DM from boss", color: "#9b5cff" },
  { app: "X", text: "trending: nothing important", color: "#ffeb00" },
  { app: "Email", text: "newsletter you forgot", color: "#ff8a3d" },
  { app: "YouTube", text: "you might like…", color: "#ff3b00" },
  { app: "Reddit", text: "37 new replies", color: "#39ff14" },
];
const REAL = [
  { app: "Focus", text: "✓ Keep going. Don't tap.", color: "#00ffd1" },
];

type Notif = {
  id: number;
  x: number;
  y: number;
  bornAt: number;
  ttl: number;
  kind: "fake" | "real";
  app: string;
  text: string;
  color: string;
};

interface Props { seed: string; onComplete: (trials: TrialResult[]) => void }

export function DistractionGame({ onComplete }: Props) {
  const [notifs, setNotifs] = useState<Notif[]>([]);
  const [timeLeft, setTimeLeft] = useState(ROUND_MS);
  const [streak, setStreak] = useState(0);
  const [flash, setFlash] = useState<"" | "correct" | "wrong">("");
  const trialsRef = useRef<TrialResult[]>([]);
  const idRef = useRef(0);
  const ttlRef = useRef(1900);
  const spawnRef = useRef(900);

  useEffect(() => {
    const start = performance.now();
    let stopped = false;

    const tick = setInterval(() => {
      if (stopped) return;
      const now = performance.now();
      const el = now - start;
      setTimeLeft(Math.max(0, ROUND_MS - el));
      if (el >= ROUND_MS) {
        stopped = true;
        clearInterval(tick);
        clearInterval(spawn);
        onComplete(trialsRef.current);
        return;
      }
      ttlRef.current = Math.max(900, 1900 - Math.floor(el / 5000) * 120);
      spawnRef.current = Math.max(380, 900 - Math.floor(el / 5000) * 60);
      setNotifs((prev) => {
        const live: Notif[] = [];
        for (const n of prev) {
          if (now - n.bornAt > n.ttl) {
            // expired fake = stole attention (wrong); expired real = correctly ignored (right)
            trialsRef.current.push({ correct: n.kind === "real", reactionMs: n.ttl });
            if (n.kind === "fake") setStreak(0);
          } else live.push(n);
        }
        return live;
      });
    }, 100);

    const spawn = setInterval(() => {
      if (stopped) return;
      setNotifs((prev) => {
        if (prev.length >= 5) return prev;
        const isReal = Math.random() < 0.18;
        const pool = isReal ? REAL : FAKE;
        const pick = pool[Math.floor(Math.random() * pool.length)];
        return [
          ...prev,
          {
            id: idRef.current++,
            x: 20 + Math.random() * (W - 260),
            y: 20 + Math.random() * (H - 80),
            bornAt: performance.now(),
            ttl: ttlRef.current,
            kind: isReal ? "real" : "fake",
            app: pick.app,
            text: pick.text,
            color: pick.color,
          },
        ];
      });
    }, spawnRef.current);

    return () => {
      stopped = true;
      clearInterval(tick);
      clearInterval(spawn);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function tap(n: Notif, e: React.MouseEvent) {
    e.stopPropagation();
    const rt = performance.now() - n.bornAt;
    const correct = n.kind === "fake";
    trialsRef.current.push({ correct, reactionMs: rt });
    if (correct) sfx.pop(); else sfx.wrong();
    setFlash(correct ? "correct" : "wrong");
    setTimeout(() => setFlash(""), 200);
    setStreak((s) => (correct ? s + 1 : 0));
    setNotifs((prev) => prev.filter((x) => x.id !== n.id));
  }

  return (
    <div className="flex flex-col items-center gap-3 select-none">
      <div className="flex items-center gap-6 font-mono text-sm">
        <div>⏱ <span className="text-accent">{Math.ceil(timeLeft / 1000)}s</span></div>
        <div>SWATTED <span className="text-primary text-glow">{streak}</span></div>
      </div>
      <div className={`relative overflow-hidden rounded-2xl bg-card/40 neon-border ${flash === "wrong" ? "shake" : ""}`} style={{ width: W, height: H }}>
        {notifs.map((n) => (
          <button
            key={n.id}
            onClick={(e) => tap(n, e)}
            className={`absolute w-60 rounded-xl px-3 py-2.5 text-left backdrop-blur-md border ${flash === "correct" && n.id === notifs[0]?.id ? "flash-correct" : ""}`}
            style={{
              left: n.x,
              top: n.y,
              background: `linear-gradient(135deg, ${n.color}22, ${n.color}08)`,
              borderColor: `${n.color}88`,
              boxShadow: `0 0 18px ${n.color}55`,
            }}
          >
            <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest font-mono" style={{ color: n.color }}>
              <span className="w-2 h-2 rounded-full" style={{ background: n.color }} /> {n.app}
            </div>
            <div className="text-sm font-medium mt-0.5 text-foreground">{n.text}</div>
          </button>
        ))}
      </div>
      <p className="text-xs text-muted-foreground max-w-md text-center">
        Tap the noise. Ignore <span className="text-accent">✓ Focus</span> messages — those are your inner voice. Tapping them breaks your streak.
      </p>
    </div>
  );
}
