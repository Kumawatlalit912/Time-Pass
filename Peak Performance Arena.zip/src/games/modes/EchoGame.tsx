import { useEffect, useRef, useState } from "react";
import type { TrialResult } from "@/games/types";
import { padTone, sfx } from "@/lib/sfx";

// Echo: Simon-says sequence memory. Watch the pads light up, then repeat the sequence.
// Each round adds one step. Round duration ~60s OR until first mistake (with one retry).

const PADS = [
  { id: 0, color: "oklch(0.70 0.13 280)" }, // indigo
  { id: 1, color: "oklch(0.74 0.10 200)" }, // teal
  { id: 2, color: "oklch(0.72 0.13 155)" }, // sage
  { id: 3, color: "oklch(0.78 0.13 75)" },  // amber
];

const ROUND_MS = 60_000;
const STEP_MS = 600;
const GAP_MS = 200;

function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6D2B79F5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function hashSeed(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

interface Props {
  seed: string;
  onComplete: (trials: TrialResult[]) => void;
}

export function EchoGame({ seed, onComplete }: Props) {
  const rngRef = useRef(mulberry32(hashSeed(seed)));
  const [sequence, setSequence] = useState<number[]>([]);
  const [playing, setPlaying] = useState(true); // true while showing sequence
  const [activePad, setActivePad] = useState<number | null>(null);
  const [userIdx, setUserIdx] = useState(0);
  const [status, setStatus] = useState<"watch" | "your-turn" | "ok" | "fail">("watch");
  const trialsRef = useRef<TrialResult[]>([]);
  const lastInputRef = useRef(performance.now());
  const startRef = useRef(performance.now());
  const endedRef = useRef(false);

  function finish() {
    if (endedRef.current) return;
    endedRef.current = true;
    onComplete(trialsRef.current);
  }

  // start first round
  useEffect(() => {
    const first = [Math.floor(rngRef.current() * 4)];
    setSequence(first);
  }, []);

  // play back the sequence whenever it changes
  useEffect(() => {
    if (sequence.length === 0) return;
    let cancelled = false;
    setPlaying(true);
    setStatus("watch");
    setUserIdx(0);
    (async () => {
      await new Promise((r) => setTimeout(r, 400));
      for (const p of sequence) {
        if (cancelled) return;
        setActivePad(p);
        padTone(p);
        await new Promise((r) => setTimeout(r, STEP_MS));
        setActivePad(null);
        await new Promise((r) => setTimeout(r, GAP_MS));
      }
      if (cancelled) return;
      setPlaying(false);
      setStatus("your-turn");
      lastInputRef.current = performance.now();
    })();
    return () => { cancelled = true; };
  }, [sequence]);

  // overall round timer
  useEffect(() => {
    const id = setInterval(() => {
      if (performance.now() - startRef.current >= ROUND_MS) finish();
    }, 250);
    return () => clearInterval(id);
  }, []);

  function tap(p: number) {
    if (playing || status !== "your-turn") return;
    const now = performance.now();
    const rt = now - lastInputRef.current;
    lastInputRef.current = now;
    const expected = sequence[userIdx];
    const correct = p === expected;
    trialsRef.current.push({ correct, reactionMs: rt });
    setActivePad(p);
    padTone(p);
    setTimeout(() => setActivePad(null), 150);

    if (!correct) {
      sfx.wrong();
      setStatus("fail");
      setTimeout(() => {
        // restart with shorter sequence (drop last 1)
        const next = sequence.slice(0, Math.max(1, sequence.length - 1));
        setSequence([...next]);
      }, 700);
      return;
    }

    if (userIdx + 1 >= sequence.length) {
      sfx.win();
      setStatus("ok");
      setTimeout(() => {
        setSequence((s) => [...s, Math.floor(rngRef.current() * 4)]);
      }, 500);
    } else {
      setUserIdx(userIdx + 1);
    }
  }

  return (
    <div className="flex flex-col items-center gap-5 select-none">
      <div className="flex items-center gap-6 text-xs font-mono uppercase tracking-[0.25em] text-muted-foreground">
        <span>Round: <span className="text-accent">{sequence.length}</span></span>
        <span>
          {status === "watch" && "watch"}
          {status === "your-turn" && "your turn"}
          {status === "ok" && "✓ nice"}
          {status === "fail" && "✗ retry"}
        </span>
      </div>
      <div className="grid grid-cols-2 gap-3 w-[320px] h-[320px] md:w-[380px] md:h-[380px]">
        {PADS.map((pad) => {
          const on = activePad === pad.id;
          return (
            <button
              key={pad.id}
              onClick={() => tap(pad.id)}
              disabled={playing}
              className="rounded-2xl border border-border transition-all"
              style={{
                background: on ? pad.color : `color-mix(in oklab, ${pad.color} 25%, var(--card))`,
                boxShadow: on ? `0 0 30px ${pad.color}` : "none",
                opacity: playing ? 0.85 : 1,
                transform: on ? "scale(0.97)" : "scale(1)",
              }}
              aria-label={`Pad ${pad.id + 1}`}
            />
          );
        })}
      </div>
      <p className="text-xs text-muted-foreground max-w-sm text-center">
        Watch the pads light up, then tap them back in the same order. Each round adds one step.
      </p>
    </div>
  );
}
