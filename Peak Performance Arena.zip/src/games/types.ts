export type ModeId =
  | "focus"
  | "decision"
  | "memory"
  | "pattern"
  | "team"
  | "reflex"
  | "nback"
  | "chaos"
  | "breath"
  | "stroop"
  | "tapflow"
  | "distract"
  | "schulte"
  | "echo";

export interface TrialResult {
  correct: boolean;
  reactionMs: number;
  isConflict?: boolean;
}

export interface PlayerRoundSummary {
  userId: string;
  displayName: string;
  avatarColor: string;
  team?: "blue" | "red";
  score: number;
  accuracy: number;
  avgReactionMs: number;
  consistency: number;
  decisionQuality: number;
  focusScore: number;
  trialsTotal: number;
  trialsCorrect: number;
}
