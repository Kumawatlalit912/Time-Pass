import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { usePlayer, getMatches, type LocalMatch } from "@/lib/player";

export const Route = createFileRoute("/stats")({
  head: () => ({ meta: [{ title: "My Stats — CogniArena" }] }),
  component: StatsPage,
});

function StatsPage() {
  const { player, loaded } = usePlayer();
  const [rows, setRows] = useState<LocalMatch[]>([]);

  useEffect(() => {
    setRows(getMatches());
    const h = () => setRows(getMatches());
    window.addEventListener("storage", h);
    return () => window.removeEventListener("storage", h);
  }, []);

  if (!loaded) return <main className="py-16 text-center text-sm text-muted-foreground">Loading…</main>;
  if (!player) {
    return (
      <main className="max-w-md mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold">No player yet</h1>
        <p className="mt-2 text-muted-foreground">Pick a name on the home page to start tracking.</p>
        <Link to="/" className="mt-5 inline-block px-5 py-2.5 rounded-lg bg-primary text-primary-foreground font-medium">Home</Link>
      </main>
    );
  }

  const avg = (k: keyof LocalMatch) =>
    rows.length ? Math.round(rows.reduce((a, r) => a + Number(r[k] ?? 0), 0) / rows.length) : 0;

  const bestByMode = (m: string) => rows.filter((r) => r.mode === m).reduce((b, r) => Math.max(b, r.score), 0);

  return (
    <main className="max-w-5xl mx-auto px-4 py-10">
      <div className="flex items-center gap-4">
        <span className="w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-bold text-white" style={{ backgroundColor: player.color }}>
          {(player.name || "?").charAt(0).toUpperCase()}
        </span>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{player.name}</h1>
          <div className="text-sm text-muted-foreground">{rows.length} matches played on this device</div>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Avg Focus" value={avg("focusScore")} />
        <StatCard label="Avg Score" value={avg("score")} />
        <StatCard label="Avg RT" value={`${avg("avgReactionMs")}ms`} />
        <StatCard label="Avg Accuracy" value={`${avg("accuracy")}%`} />
      </div>

      <div className="mt-6 grid md:grid-cols-3 gap-3">
        <BestCard label="Focus Challenge" score={bestByMode("focus")} />
        <BestCard label="Rapid Decision" score={bestByMode("decision")} />
        <BestCard label="Memory Matrix" score={bestByMode("memory")} />
      </div>

      <h2 className="mt-10 text-lg font-bold">Recent matches</h2>
      <div className="mt-3 rounded-2xl border border-border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-secondary text-muted-foreground">
            <tr>
              <th className="text-left p-3">When</th>
              <th className="text-left p-3">Mode</th>
              <th className="text-left p-3 hidden md:table-cell">Where</th>
              <th className="text-right p-3">Score</th>
              <th className="text-right p-3 hidden md:table-cell">Acc</th>
              <th className="text-right p-3 hidden md:table-cell">RT</th>
              <th className="text-right p-3">Focus</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-border">
                <td className="p-3 text-muted-foreground">{new Date(r.createdAt).toLocaleString()}</td>
                <td className="p-3 capitalize">{r.mode}</td>
                <td className="p-3 hidden md:table-cell text-muted-foreground">{r.context === "room" ? `Room ${r.roomCode}` : "Solo"}</td>
                <td className="p-3 text-right font-mono">{r.score}</td>
                <td className="p-3 text-right font-mono hidden md:table-cell">{r.accuracy}%</td>
                <td className="p-3 text-right font-mono hidden md:table-cell">{r.avgReactionMs}ms</td>
                <td className="p-3 text-right font-mono text-primary">{r.focusScore}</td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">No matches yet — pick a mode on the home page.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </main>
  );
}

function StatCard({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="p-4 rounded-2xl border border-border bg-card">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 text-2xl font-bold font-mono">{value}</div>
    </div>
  );
}

function BestCard({ label, score }: { label: string; score: number }) {
  return (
    <div className="p-4 rounded-2xl border border-border bg-card">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">Best · {label}</div>
      <div className="mt-1 text-2xl font-bold font-mono text-primary">{score || "—"}</div>
    </div>
  );
}
