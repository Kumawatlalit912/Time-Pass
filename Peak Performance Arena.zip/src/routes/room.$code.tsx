import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import type { RealtimeChannel } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { usePlayer, recordMatch } from "@/lib/player";
import { MODES, getMode } from "@/games/registry";
import type { ModeId, TrialResult, PlayerRoundSummary } from "@/games/types";
import { FocusGame } from "@/games/modes/FocusGame";
import { DecisionGame } from "@/games/modes/DecisionGame";
import { MemoryGame } from "@/games/modes/MemoryGame";
import { ReflexGame } from "@/games/modes/ReflexGame";
import { NBackGame } from "@/games/modes/NBackGame";
import { ChaosMathGame } from "@/games/modes/ChaosMathGame";
import { BreathGame } from "@/games/modes/BreathGame";
import { StroopGame } from "@/games/modes/StroopGame";
import { TapFlowGame } from "@/games/modes/TapFlowGame";
import { DistractionGame } from "@/games/modes/DistractionGame";
import { SchulteGame } from "@/games/modes/SchulteGame";
import { EchoGame } from "@/games/modes/EchoGame";

const GAME_MAP: Record<ModeId, React.ComponentType<{ seed: string; onComplete: (t: TrialResult[]) => void }> | undefined> = {
  focus: FocusGame, decision: DecisionGame, memory: MemoryGame, reflex: ReflexGame,
  nback: NBackGame, chaos: ChaosMathGame, breath: BreathGame, stroop: StroopGame,
  tapflow: TapFlowGame, distract: DistractionGame, schulte: SchulteGame, echo: EchoGame,
  pattern: undefined, team: undefined,
};
import { summarize } from "@/lib/scoring";
import { toast } from "sonner";
import { Copy, Crown, Play } from "lucide-react";

export const Route = createFileRoute("/room/$code")({
  component: RoomPage,
});

type Phase = "lobby" | "playing" | "results";
type Presence = {
  userId: string;
  displayName: string;
  avatarColor: string;
  isHost: boolean;
  team: "blue" | "red";
};

function RoomPage() {
  const { code } = Route.useParams();
  const { player, loaded } = usePlayer();
  const navigate = useNavigate();

  const [members, setMembers] = useState<Presence[]>([]);
  const [phase, setPhase] = useState<Phase>("lobby");
  const [mode, setMode] = useState<ModeId>("focus");
  const [seed, setSeed] = useState<string>("");
  const [results, setResults] = useState<PlayerRoundSummary[]>([]);
  const [teamsOn, setTeamsOn] = useState(false);
  const channelRef = useRef<RealtimeChannel | null>(null);
  const submittedRef = useRef(false);

  const me = members.find((m) => m.userId === player?.id);
  const isHost = me?.isHost ?? false;
  const hostId = members.find((m) => m.isHost)?.userId;

  useEffect(() => {
    if (loaded && !player) {
      navigate({ to: "/", replace: true });
    }
  }, [loaded, player, navigate]);

  useEffect(() => {
    if (!player) return;
    const ch = supabase.channel(`room:${code}`, { config: { presence: { key: player.id } } });

    ch.on("presence", { event: "sync" }, () => {
      const state = ch.presenceState<Presence>();
      const all: Presence[] = [];
      for (const k in state) for (const p of state[k]) all.push(p);
      const hasHost = all.some((m) => m.isHost);
      if (!hasHost && all.length) {
        all.sort((a, b) => a.userId.localeCompare(b.userId));
        all[0].isHost = true;
      }
      setMembers(all);
    });

    ch.on("broadcast", { event: "start" }, ({ payload }) => {
      setMode(payload.mode);
      setSeed(payload.seed);
      setTeamsOn(payload.teamsOn);
      setResults([]);
      submittedRef.current = false;
      setPhase("playing");
    });

    ch.on("broadcast", { event: "result" }, ({ payload }) => {
      setResults((prev) => prev.some((r) => r.userId === payload.userId) ? prev : [...prev, payload as PlayerRoundSummary]);
    });

    ch.on("broadcast", { event: "return-to-lobby" }, () => {
      setPhase("lobby");
      setResults([]);
    });

    ch.subscribe(async (status) => {
      if (status === "SUBSCRIBED") {
        await ch.track({
          userId: player.id,
          displayName: player.name,
          avatarColor: player.color,
          isHost: false,
          team: "blue",
        } as Presence);
      }
    });

    channelRef.current = ch;
    return () => {
      ch.unsubscribe();
      supabase.removeChannel(ch);
    };
  }, [player, code]);

  useEffect(() => {
    if (phase === "playing" && results.length > 0 && results.length >= members.length) {
      setPhase("results");
    }
  }, [results, members.length, phase]);

  async function startGame() {
    if (!channelRef.current || !isHost) return;
    if (members.length < 1) return;
    const newSeed = `${code}-${Date.now()}`;
    await channelRef.current.send({
      type: "broadcast",
      event: "start",
      payload: { mode, seed: newSeed, teamsOn },
    });
  }

  function onTrialsComplete(trials: TrialResult[]) {
    if (!player || submittedRef.current) return;
    submittedRef.current = true;
    const team = teamsOn
      ? (members.findIndex((m) => m.userId === player.id) % 2 === 0 ? "blue" : "red")
      : undefined;
    const summary = summarize(trials, {
      userId: player.id,
      displayName: player.name,
      avatarColor: player.color,
      team,
    });
    channelRef.current?.send({ type: "broadcast", event: "result", payload: summary });
    setResults((prev) => prev.some((r) => r.userId === summary.userId) ? prev : [...prev, summary]);
    recordMatch({
      mode,
      score: summary.score,
      accuracy: summary.accuracy,
      avgReactionMs: summary.avgReactionMs,
      consistency: summary.consistency,
      focusScore: summary.focusScore,
      context: "room",
      roomCode: code,
    });
  }

  async function backToLobby() {
    if (!channelRef.current) return;
    await channelRef.current.send({ type: "broadcast", event: "return-to-lobby", payload: {} });
    setPhase("lobby");
    setResults([]);
  }

  function copyLink() {
    navigator.clipboard.writeText(window.location.href);
    toast.success("Room link copied");
  }

  if (!loaded) return <main className="py-16 text-center text-sm text-muted-foreground">Loading…</main>;
  if (!player) return null;

  if (phase === "playing") {
    const Game = GAME_MAP[mode] ?? FocusGame;
    return (
      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="text-xs font-mono uppercase tracking-[0.3em] text-muted-foreground mb-6 text-center">
          <span className="text-accent">{getMode(mode)?.name}</span> · room {code} · {members.length} player{members.length === 1 ? "" : "s"}
        </div>
        <Game seed={seed} onComplete={onTrialsComplete} />
        {results.length > 0 && (
          <div className="mt-8 max-w-md mx-auto">
            <div className="text-xs text-muted-foreground mb-2">Finished: {results.length}/{members.length}</div>
            <div className="space-y-1">
              {results.map((r) => (
                <div key={r.userId} className="flex justify-between text-sm p-2 rounded bg-secondary">
                  <span>{r.displayName}</span>
                  <span className="font-mono">{r.score}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    );
  }

  if (phase === "results") {
    const sorted = [...results].sort((a, b) => b.score - a.score);
    const teamScores = teamsOn
      ? sorted.reduce(
          (acc, r) => { if (r.team) acc[r.team] += r.score; return acc; },
          { blue: 0, red: 0 } as Record<string, number>,
        )
      : null;
    return (
      <main className="max-w-4xl mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold tracking-tight">Results</h1>
        <p className="text-muted-foreground mt-1">{getMode(mode)?.name} · room {code}</p>

        {teamScores && (
          <div className="grid grid-cols-2 gap-3 mt-6">
            <div className="p-4 rounded-2xl border border-border bg-card">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Team Blue</div>
              <div className="text-3xl font-bold mt-1" style={{ color: "#3b82f6" }}>{teamScores.blue}</div>
            </div>
            <div className="p-4 rounded-2xl border border-border bg-card">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Team Red</div>
              <div className="text-3xl font-bold mt-1" style={{ color: "#ef4444" }}>{teamScores.red}</div>
            </div>
          </div>
        )}

        <div className="mt-6 rounded-2xl border border-border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-secondary text-muted-foreground">
              <tr>
                <th className="text-left p-3">#</th>
                <th className="text-left p-3">Player</th>
                <th className="text-right p-3">Score</th>
                <th className="text-right p-3 hidden md:table-cell">Acc</th>
                <th className="text-right p-3 hidden md:table-cell">RT</th>
                <th className="text-right p-3 hidden md:table-cell">Cons</th>
                <th className="text-right p-3">Focus</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((r, i) => (
                <tr key={r.userId} className="border-t border-border">
                  <td className="p-3 font-mono">{i + 1}</td>
                  <td className="p-3 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full" style={{ backgroundColor: r.avatarColor }} />
                    {r.displayName}
                  </td>
                  <td className="p-3 text-right font-mono font-semibold">{r.score}</td>
                  <td className="p-3 text-right font-mono hidden md:table-cell">{r.accuracy}%</td>
                  <td className="p-3 text-right font-mono hidden md:table-cell">{r.avgReactionMs}ms</td>
                  <td className="p-3 text-right font-mono hidden md:table-cell">{r.consistency}</td>
                  <td className="p-3 text-right font-mono text-primary">{r.focusScore}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-6 flex gap-3 flex-wrap">
          {isHost && (
            <button onClick={backToLobby} className="px-5 py-2.5 rounded-lg bg-primary text-primary-foreground font-medium">
              Back to room lobby
            </button>
          )}
          <Link to="/stats" className="px-5 py-2.5 rounded-lg border border-border bg-card font-medium hover:bg-secondary">
            My stats
          </Link>
          <Link to="/" className="px-5 py-2.5 rounded-lg border border-border bg-card font-medium hover:bg-secondary">
            Home
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="max-w-4xl mx-auto px-4 py-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Room code</div>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-4xl font-mono font-bold tracking-widest">{code}</span>
            <button onClick={copyLink} className="p-2 rounded-md hover:bg-secondary text-muted-foreground" aria-label="Copy link">
              <Copy className="w-4 h-4" />
            </button>
          </div>
          <p className="text-xs text-muted-foreground mt-1">Share the code or link with up to 9 others.</p>
        </div>
        <div className="text-sm text-muted-foreground">{members.length}/10 players</div>
      </div>

      <div className="mt-6 grid md:grid-cols-2 gap-4">
        <div className="p-5 rounded-2xl border border-border bg-card">
          <h2 className="font-semibold mb-3">Players</h2>
          <ul className="space-y-2">
            {members.map((m) => (
              <li key={m.userId} className="flex items-center gap-2 text-sm">
                <span className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] text-white font-semibold" style={{ backgroundColor: m.avatarColor }}>
                  {m.displayName[0]?.toUpperCase()}
                </span>
                <span>{m.displayName}</span>
                {m.userId === hostId && <Crown className="w-3 h-3 text-warning" />}
                {m.userId === player.id && <span className="text-xs text-muted-foreground">(you)</span>}
              </li>
            ))}
            {members.length === 0 && <li className="text-sm text-muted-foreground">Connecting…</li>}
          </ul>
        </div>

        <div className="p-5 rounded-2xl border border-border bg-card">
          <h2 className="font-semibold mb-3">Game settings</h2>
          <label className="text-xs uppercase tracking-wider text-muted-foreground">Mode</label>
          <div className="mt-2 grid grid-cols-1 gap-2">
            {MODES.filter((m) => m.available).map((m) => (
              <button
                key={m.id}
                disabled={!isHost}
                onClick={() => setMode(m.id)}
                className={`text-left p-3 rounded-lg border transition ${
                  mode === m.id ? "border-primary bg-accent" : "border-border bg-background hover:bg-secondary"
                } ${!isHost ? "opacity-60 cursor-not-allowed" : ""}`}
              >
                <div className="font-medium text-sm">{m.name}</div>
                <div className="text-xs text-muted-foreground">{m.tagline}</div>
              </button>
            ))}
          </div>
          <label className="mt-4 flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={teamsOn}
              disabled={!isHost}
              onChange={(e) => setTeamsOn(e.target.checked)}
            />
            Team mode (Blue vs Red)
          </label>
          <button
            onClick={startGame}
            disabled={!isHost}
            className="mt-5 w-full h-11 rounded-lg bg-primary text-primary-foreground font-medium disabled:opacity-40 flex items-center justify-center gap-2"
          >
            <Play className="w-4 h-4" /> {isHost ? "Start match" : "Waiting for host…"}
          </button>
        </div>
      </div>
    </main>
  );
}
