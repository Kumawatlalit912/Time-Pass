import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { usePlayer, recordMatch } from "@/lib/player";
import { FocusGame } from "@/games/modes/FocusGame";
import { DecisionGame } from "@/games/modes/DecisionGame";
import { MemoryGame } from "@/games/modes/MemoryGame";
import { ReflexGame } from "@/games/modes/ReflexGame";
import { NBackGame } from "@/games/modes/NBackGame";
import { ChaosMathGame } from "@/games/modes/ChaosMathGame";
import { BreathGame } from "@/games/modes/BreathGame";
import { StroopGame } from "@/games/modes/StroopGame";
import { TapFlowGame } from "@/games/modes/TapFlowGame";
import { DistractionGame } from "@/games/modes/DistractionGame";
import { SchulteGame } from "@/games/modes/SchulteGame";
import { EchoGame } from "@/games/modes/EchoGame";
import { summarize } from "@/lib/scoring";
import { getMode } from "@/games/registry";
import type { TrialResult, PlayerRoundSummary, ModeId } from "@/games/types";

export const Route = createFileRoute("/play/$mode")({ component: SoloPlay });

const GAMES: Record<ModeId, React.ComponentType<{ seed: string; onComplete: (t: TrialResult[]) => void }> | undefined> = {
  focus: FocusGame,
  decision: DecisionGame,
  memory: MemoryGame,
  reflex: ReflexGame,
  nback: NBackGame,
  chaos: ChaosMathGame,
  breath: BreathGame,
  stroop: StroopGame,
  tapflow: TapFlowGame,
  distract: DistractionGame,
  schulte: SchulteGame,
  echo: EchoGame,
  pattern: undefined,
  team: undefined,
};

function SoloPlay() {
  const { mode } = Route.useParams() as { mode: ModeId };
  const { player, loaded } = usePlayer();
  const navigate = useNavigate();
  const [seed] = useState(() => `solo-${Date.now()}-${Math.random()}`);
  const [result, setResult] = useState<PlayerRoundSummary | null>(null);

  useEffect(() => {
    if (loaded && !player) navigate({ to: "/", replace: true });
  }, [loaded, player, navigate]);

  if (!loaded) return <main className="py-16 text-center text-sm text-muted-foreground">Loading…</main>;
  if (!player) return null;
  const meta = getMode(mode);
  const Game = GAMES[mode];
  if (!meta?.available || !Game) {
    return (
      <main className="max-w-2xl mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold">Mode not available</h1>
        <Link to="/" className="mt-4 inline-block text-primary underline">Back home</Link>
      </main>
    );
  }

  function onComplete(trials: TrialResult[]) {
    const summary = summarize(trials, {
      userId: player!.id,
      displayName: player!.name,
      avatarColor: player!.color,
    });
    recordMatch({
      mode,
      score: summary.score,
      accuracy: summary.accuracy,
      avgReactionMs: summary.avgReactionMs,
      consistency: summary.consistency,
      focusScore: summary.focusScore,
      context: "solo",
    });
    setResult(summary);
  }

  if (result) {
    return (
      <main className="max-w-xl mx-auto px-4 py-12">
        <div className="text-center">
          <div className="text-xs uppercase tracking-[0.3em] font-mono text-accent">{meta.name} · solo</div>
          <div className="mt-3 text-7xl font-bold font-mono text-glow text-primary">{result.score}</div>
          <div className="text-sm text-muted-foreground">total score</div>
        </div>
        <div className="mt-8 grid grid-cols-2 gap-3">
          <Stat label="Focus" value={result.focusScore} />
          <Stat label="Accuracy" value={`${result.accuracy}%`} />
          <Stat label="Avg RT" value={`${result.avgReactionMs}ms`} />
          <Stat label="Consistency" value={result.consistency} />
        </div>
        <div className="mt-6 flex gap-3 justify-center flex-wrap">
          <button
            onClick={() => { setResult(null); navigate({ to: "/play/$mode", params: { mode }, replace: true }); window.location.reload(); }}
            className="px-5 py-2.5 rounded-lg bg-primary text-primary-foreground font-medium glow-magenta"
          >
            Play again
          </button>
          <Link to="/stats" className="px-5 py-2.5 rounded-lg border border-border bg-card font-medium hover:bg-secondary">My stats</Link>
          <Link to="/" className="px-5 py-2.5 rounded-lg border border-border bg-card font-medium hover:bg-secondary">Home</Link>
        </div>
      </main>
    );
  }

  return (
    <main className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-xs font-mono uppercase tracking-[0.3em] text-muted-foreground mb-6 text-center">
        <span className="text-accent">{meta.name}</span> · solo · {player.name}
      </div>
      <Game seed={seed} onComplete={onComplete} />
    </main>
  );
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="p-4 rounded-2xl border border-border bg-card/60 text-center neon-border">
      <div className="text-[10px] uppercase tracking-widest font-mono text-muted-foreground">{label}</div>
      <div className="mt-1 text-2xl font-bold font-mono text-glow text-accent">{value}</div>
    </div>
  );
}
