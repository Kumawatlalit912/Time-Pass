import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { savePlayer, usePlayer, PLAYER_COLORS } from "@/lib/player";
import { MODES } from "@/games/registry";
import { toast } from "sonner";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CogniArena — Playful brain games for focus & reaction" },
      { name: "description", content: "Twelve bite-sized brain games. Drop in with a name. Play solo or in rooms of up to ten." },
    ],
  }),
  component: Landing,
});

function randomCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 6; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

// Bento tile palette assignments — cycles through 4 surface flavors
const TILE_STYLES = [
  { bg: "var(--peach-soft)", accent: "var(--peach)" },
  { bg: "var(--sky-soft)", accent: "var(--sky)" },
  { bg: "var(--cream-warm)", accent: "var(--indigo)" },
  { bg: "color-mix(in oklab, var(--sky) 25%, var(--cream))", accent: "var(--indigo-deep)" },
];

// Bento size pattern per index — creates the asymmetric grid
const TILE_SPANS = [
  "md:col-span-2 md:row-span-2", // 0 - large
  "md:col-span-1 md:row-span-1",
  "md:col-span-1 md:row-span-1",
  "md:col-span-1 md:row-span-2", // 3 - tall
  "md:col-span-2 md:row-span-1", // 4 - wide
  "md:col-span-1 md:row-span-1",
  "md:col-span-1 md:row-span-1",
  "md:col-span-1 md:row-span-1",
  "md:col-span-2 md:row-span-1", // 8 - wide
  "md:col-span-1 md:row-span-1",
  "md:col-span-1 md:row-span-1",
  "md:col-span-1 md:row-span-1",
];

function Landing() {
  const navigate = useNavigate();
  const { player } = usePlayer();
  const [name, setName] = useState(player?.name ?? "");
  const [color, setColor] = useState(player?.color ?? PLAYER_COLORS[0]);
  const [code, setCode] = useState("");

  function ensurePlayer(): boolean {
    if (player) return true;
    const trimmed = name.trim();
    if (trimmed.length < 2) {
      toast.error("Enter a name (2+ characters) first");
      return false;
    }
    savePlayer(trimmed, color);
    return true;
  }

  function createRoom() {
    if (!ensurePlayer()) return;
    navigate({ to: "/room/$code", params: { code: randomCode() } });
  }

  function joinRoom(e: React.FormEvent) {
    e.preventDefault();
    if (!ensurePlayer()) return;
    const c = code.trim().toUpperCase();
    if (c.length < 4) return toast.error("Enter a valid room code");
    navigate({ to: "/room/$code", params: { code: c } });
  }

  function playSolo(modeId: string) {
    if (!ensurePlayer()) return;
    navigate({ to: "/play/$mode", params: { mode: modeId } });
  }

  function updateName() {
    const trimmed = name.trim();
    if (trimmed.length < 2) return;
    savePlayer(trimmed, color);
    toast.success("Saved");
  }

  const availableModes = MODES.filter((m) => m.available);
  const upcomingModes = MODES.filter((m) => !m.available);

  return (
    <main className="bg-background text-foreground min-h-screen">
      {/* ─────── HERO ─────── */}
      <section className="px-6 pt-16 pb-12 md:pt-24 md:pb-16">
        <div className="max-w-6xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[color:var(--peach-soft)] text-[11px] font-semibold text-[color:var(--ink)] mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-[color:var(--indigo)] animate-pulse" />
            12 games · multiplayer · no signup
          </div>
          <h1 className="font-display text-5xl sm:text-6xl md:text-7xl font-extrabold tracking-tight max-w-4xl">
            Tiny brain games.{" "}
            <span className="text-[color:var(--indigo)]">Big focus.</span>
          </h1>
          <p className="mt-6 text-lg md:text-xl text-[color:var(--ink-soft)] max-w-2xl">
            Drop in with a name. Play solo, or spin up a room and battle up to ten friends in real time.
          </p>
        </div>
      </section>

      {/* ─────── ENTRY CARD ─────── */}
      <section className="px-6 pb-16">
        <div className="max-w-6xl mx-auto">
          <div className="rounded-3xl bg-card border border-border p-6 md:p-8 shadow-soft">
            <div className="flex flex-col lg:flex-row gap-6 lg:items-end">
              <div className="flex-1">
                <label className="text-xs font-semibold uppercase tracking-wider text-[color:var(--ink-faint)] mb-2 block">
                  Your name
                </label>
                <div className="flex items-center gap-3">
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Alex"
                    maxLength={24}
                    className="flex-1 bg-background border-2 border-border rounded-xl px-4 py-3 text-base font-medium focus:outline-none focus:border-[color:var(--indigo)] transition-colors"
                  />
                  {player && (
                    <button
                      onClick={updateName}
                      className="px-4 py-3 rounded-xl border-2 border-border text-sm font-semibold hover:border-[color:var(--indigo)] transition-colors"
                    >
                      Save
                    </button>
                  )}
                </div>
                <div className="flex flex-wrap gap-2 mt-3">
                  {PLAYER_COLORS.map((c) => (
                    <button
                      key={c}
                      onClick={() => { setColor(c); if (player) savePlayer(player.name, c); }}
                      className={`w-7 h-7 rounded-full transition-all ${
                        color === c ? "ring-2 ring-offset-2 ring-[color:var(--indigo)] ring-offset-card scale-110" : "hover:scale-110"
                      }`}
                      style={{ backgroundColor: c }}
                      aria-label="Pick color"
                    />
                  ))}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 lg:w-auto">
                <button
                  onClick={createRoom}
                  className="px-6 py-3 rounded-xl bg-[color:var(--indigo)] text-[color:var(--cream)] font-semibold hover:bg-[color:var(--indigo-deep)] transition-colors shadow-pop"
                >
                  + Create room
                </button>
                <form onSubmit={joinRoom} className="flex rounded-xl border-2 border-border overflow-hidden bg-background">
                  <input
                    value={code}
                    onChange={(e) => setCode(e.target.value.toUpperCase())}
                    placeholder="ROOM CODE"
                    maxLength={6}
                    className="bg-transparent px-4 py-3 uppercase tracking-widest text-sm font-mono w-32 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="px-5 bg-[color:var(--peach)] text-[color:var(--ink)] text-sm font-semibold hover:bg-[color:var(--peach-soft)] transition-colors"
                  >
                    Join
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─────── BENTO GAME GRID ─────── */}
      <section className="px-6 pb-20">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-end justify-between mb-6 flex-wrap gap-2">
            <h2 className="font-display text-3xl md:text-4xl font-bold">
              Pick your game
            </h2>
            <p className="text-sm text-[color:var(--ink-soft)]">
              {availableModes.length} ready · {upcomingModes.length} coming soon
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 auto-rows-[160px] gap-3 md:gap-4">
            {availableModes.map((m, i) => {
              const style = TILE_STYLES[i % TILE_STYLES.length];
              const span = TILE_SPANS[i] ?? "md:col-span-1 md:row-span-1";
              const isLarge = span.includes("col-span-2") && span.includes("row-span-2");
              return (
                <button
                  key={m.id}
                  onClick={() => playSolo(m.id)}
                  className={`group relative text-left rounded-2xl border border-border p-5 flex flex-col justify-between hover:-translate-y-0.5 hover:shadow-pop transition-all overflow-hidden ${span}`}
                  style={{ backgroundColor: style.bg }}
                >
                  <div className="flex items-start justify-between">
                    <span className="font-mono text-[10px] font-semibold tracking-widest text-[color:var(--ink-faint)]">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span
                      className="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full"
                      style={{ backgroundColor: style.accent, color: "var(--cream)" }}
                    >
                      {(m.vibe ?? "focus")}
                    </span>
                  </div>
                  <div>
                    <h3 className={`font-display font-bold text-[color:var(--ink)] mb-1.5 ${isLarge ? "text-3xl md:text-4xl" : "text-lg md:text-xl"}`}>
                      {m.name}
                    </h3>
                    <p className={`text-[color:var(--ink-soft)] leading-snug ${isLarge ? "text-base line-clamp-3" : "text-xs line-clamp-2"}`}>
                      {m.tagline}
                    </p>
                    <div className="mt-3 flex items-center gap-2 text-[10px] font-mono uppercase tracking-wider text-[color:var(--ink-faint)]">
                      <span>{m.duration}</span>
                      <span className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity text-[color:var(--indigo)] font-bold">
                        Play →
                      </span>
                    </div>
                  </div>
                </button>
              );
            })}
            {upcomingModes.map((m, i) => (
              <div
                key={m.id}
                className="rounded-2xl border-2 border-dashed border-border p-5 flex flex-col justify-between opacity-60"
              >
                <div className="flex items-start justify-between">
                  <span className="font-mono text-[10px] font-semibold tracking-widest text-[color:var(--ink-faint)]">
                    {String(availableModes.length + i + 1).padStart(2, "0")}
                  </span>
                  <span className="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border border-border text-[color:var(--ink-faint)]">
                    Soon
                  </span>
                </div>
                <div>
                  <h3 className="font-display font-bold text-lg text-[color:var(--ink)] mb-1">{m.name}</h3>
                  <p className="text-xs text-[color:var(--ink-soft)] leading-snug line-clamp-2">{m.tagline}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─────── SQUAD ─────── */}
      <section className="px-6 pb-20">
        <div className="max-w-6xl mx-auto rounded-3xl bg-gradient-arcade p-8 md:p-12 text-center">
          <h2 className="font-display text-4xl md:text-5xl font-bold text-[color:var(--ink)] mb-4">
            Squad up. Zero friction.
          </h2>
          <p className="text-[color:var(--ink-soft)] max-w-xl mx-auto text-base md:text-lg">
            Host a room. Share the 6-character code. Up to ten players. Live leaderboard per round.
          </p>
          <div className="mt-10 grid grid-cols-3 gap-4 max-w-md mx-auto">
            {[
              { n: "10", l: "Players" },
              { n: "6", l: "Char code" },
              { n: "0", l: "Sign-ups" },
            ].map((s) => (
              <div key={s.l} className="rounded-2xl bg-[color:var(--cream)]/70 backdrop-blur p-4">
                <span className="font-display text-4xl md:text-5xl font-extrabold text-[color:var(--indigo)] block">{s.n}</span>
                <span className="mt-1 text-[10px] tracking-widest uppercase font-semibold text-[color:var(--ink-soft)]">
                  {s.l}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-border">
        <div className="max-w-6xl mx-auto px-6 py-6 flex flex-col md:flex-row justify-between items-center gap-2 text-xs text-[color:var(--ink-faint)]">
          <span className="font-semibold">CogniArena</span>
          <span>Made for focused minds · MMXXVI</span>
        </div>
      </footer>
    </main>
  );
}
