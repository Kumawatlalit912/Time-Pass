import { useEffect, useState } from "react";
import type { ModeId } from "@/games/types";

const COLORS = ["#ff00aa", "#00ffd1", "#9b5cff", "#ffeb00", "#ff3b00", "#39ff14", "#00b0ff", "#ff8a3d"];

export interface Player {
  id: string;
  name: string;
  color: string;
}

export interface LocalMatch {
  id: string;
  mode: ModeId;
  score: number;
  accuracy: number;
  avgReactionMs: number;
  consistency: number;
  focusScore: number;
  context: "solo" | "room";
  roomCode?: string;
  createdAt: number;
}

const PLAYER_KEY = "cogniarena.player";
const MATCHES_KEY = "cogniarena.matches";

function uuid() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return "p-" + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export function getPlayer(): Player | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(PLAYER_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as Player;
  } catch {
    return null;
  }
}

export function savePlayer(name: string, color?: string): Player {
  const existing = getPlayer();
  const p: Player = {
    id: existing?.id ?? uuid(),
    name: name.trim().slice(0, 24) || "Player",
    color: color ?? existing?.color ?? COLORS[Math.floor(Math.random() * COLORS.length)],
  };
  localStorage.setItem(PLAYER_KEY, JSON.stringify(p));
  window.dispatchEvent(new Event("cogniarena:player"));
  return p;
}

export function clearPlayer() {
  localStorage.removeItem(PLAYER_KEY);
  window.dispatchEvent(new Event("cogniarena:player"));
}

export function usePlayer(): { player: Player | null; loaded: boolean } {
  const [p, setP] = useState<Player | null>(null);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    setP(getPlayer());
    setLoaded(true);
    const h = () => setP(getPlayer());
    window.addEventListener("cogniarena:player", h);
    window.addEventListener("storage", h);
    return () => {
      window.removeEventListener("cogniarena:player", h);
      window.removeEventListener("storage", h);
    };
  }, []);
  return { player: p, loaded };
}

export function recordMatch(m: Omit<LocalMatch, "id" | "createdAt">): LocalMatch {
  const entry: LocalMatch = { ...m, id: uuid(), createdAt: Date.now() };
  const all = getMatches();
  all.unshift(entry);
  localStorage.setItem(MATCHES_KEY, JSON.stringify(all.slice(0, 200)));
  return entry;
}

export function getMatches(): LocalMatch[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(MATCHES_KEY);
    return raw ? (JSON.parse(raw) as LocalMatch[]) : [];
  } catch {
    return [];
  }
}

export const PLAYER_COLORS = COLORS;
