import type { TrialResult, PlayerRoundSummary } from "@/games/types";

const MIN_VALID_RT = 120; // ms — below this is anticipation, drop

export function summarize(
  trials: TrialResult[],
  ctx: { userId: string; displayName: string; avatarColor: string; team?: "blue" | "red" },
): PlayerRoundSummary {
  const cleaned = trials.filter((t) => t.reactionMs >= MIN_VALID_RT || !t.correct);
  const total = cleaned.length || 1;
  const correct = cleaned.filter((t) => t.correct).length;
  const accuracy = (correct / total) * 100;

  const rts = cleaned.filter((t) => t.correct).map((t) => t.reactionMs);
  const mean = rts.length ? rts.reduce((a, b) => a + b, 0) / rts.length : 0;
  const variance = rts.length
    ? rts.reduce((a, b) => a + (b - mean) ** 2, 0) / rts.length
    : 0;
  const stddev = Math.sqrt(variance);
  const cv = mean > 0 ? stddev / mean : 1;
  const consistency = Math.max(0, Math.min(100, (1 - cv) * 100));

  const conflictTrials = cleaned.filter((t) => t.isConflict);
  const conflictCorrect = conflictTrials.filter((t) => t.correct).length;
  const decisionQuality = conflictTrials.length
    ? (conflictCorrect / conflictTrials.length) * 100
    : accuracy;

  // Speed bonus only when accurate enough — penalizes guess-spamming
  const speedBonus =
    accuracy >= 70 && mean > 0 ? Math.max(0, Math.min(500, (700 - mean) * 0.8)) : 0;

  const falsePositives = cleaned.filter((t) => !t.correct).length;
  const fpPenalty = falsePositives * 25;

  const consistencyBonus = consistency * 3;

  const score = Math.max(
    0,
    Math.round(accuracy * 10 + speedBonus + consistencyBonus - fpPenalty),
  );

  const focusScore = Math.round(
    accuracy * 5 + consistency * 4 + Math.max(0, 100 - falsePositives * 10),
  );

  return {
    userId: ctx.userId,
    displayName: ctx.displayName,
    avatarColor: ctx.avatarColor,
    team: ctx.team,
    score,
    accuracy: Math.round(accuracy * 10) / 10,
    avgReactionMs: Math.round(mean),
    consistency: Math.round(consistency * 10) / 10,
    decisionQuality: Math.round(decisionQuality * 10) / 10,
    focusScore,
    trialsTotal: total,
    trialsCorrect: correct,
  };
}

export function xpFromScore(score: number) {
  return Math.round(score / 10);
}

export const SKILL_TIERS = [
  { name: "Rookie", minXp: 0 },
  { name: "Apprentice", minXp: 500 },
  { name: "Operator", minXp: 1500 },
  { name: "Specialist", minXp: 4000 },
  { name: "Elite", minXp: 9000 },
  { name: "Grandmaster", minXp: 20000 },
] as const;

export function tierFromXp(xp: number): { name: string; minXp: number } {
  let current: { name: string; minXp: number } = SKILL_TIERS[0];
  for (const t of SKILL_TIERS) if (xp >= t.minXp) current = t;
  return current;
}
