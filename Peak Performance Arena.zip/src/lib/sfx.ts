// Tiny Web Audio sound effects — no assets, no network.
// Usage: import { sfx } from "@/lib/sfx"; sfx.click(); sfx.correct(); sfx.wrong();

type Voice = "click" | "tap" | "correct" | "wrong" | "combo" | "tick" | "win" | "pop" | "whoosh" | "pad";

let ctx: AudioContext | null = null;
const STORAGE_KEY = "ca:sfx:muted";

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext);
    if (!AC) return null;
    ctx = new AC();
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

export function isMuted(): boolean {
  if (typeof window === "undefined") return false;
  return window.localStorage.getItem(STORAGE_KEY) === "1";
}
export function setMuted(m: boolean) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, m ? "1" : "0");
}

function tone(opts: {
  freq: number;
  endFreq?: number;
  type?: OscillatorType;
  duration: number;
  gain?: number;
  delay?: number;
}) {
  if (isMuted()) return;
  const ac = getCtx();
  if (!ac) return;
  const t0 = ac.currentTime + (opts.delay ?? 0);
  const osc = ac.createOscillator();
  const g = ac.createGain();
  osc.type = opts.type ?? "sine";
  osc.frequency.setValueAtTime(opts.freq, t0);
  if (opts.endFreq != null) {
    osc.frequency.exponentialRampToValueAtTime(Math.max(1, opts.endFreq), t0 + opts.duration);
  }
  const peak = opts.gain ?? 0.12;
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(peak, t0 + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + opts.duration);
  osc.connect(g).connect(ac.destination);
  osc.start(t0);
  osc.stop(t0 + opts.duration + 0.02);
}

function noise(duration: number, gain = 0.08) {
  if (isMuted()) return;
  const ac = getCtx();
  if (!ac) return;
  const buf = ac.createBuffer(1, Math.floor(ac.sampleRate * duration), ac.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
  const src = ac.createBufferSource();
  src.buffer = buf;
  const g = ac.createGain();
  g.gain.value = gain;
  src.connect(g).connect(ac.destination);
  src.start();
}

const voices: Record<Voice, () => void> = {
  click: () => tone({ freq: 620, endFreq: 480, type: "triangle", duration: 0.06, gain: 0.08 }),
  tap: () => tone({ freq: 880, endFreq: 660, type: "sine", duration: 0.05, gain: 0.07 }),
  correct: () => {
    tone({ freq: 660, type: "triangle", duration: 0.09, gain: 0.1 });
    tone({ freq: 990, type: "triangle", duration: 0.12, gain: 0.09, delay: 0.06 });
  },
  wrong: () => {
    tone({ freq: 220, endFreq: 110, type: "sawtooth", duration: 0.22, gain: 0.1 });
    noise(0.08, 0.04);
  },
  combo: () => {
    tone({ freq: 880, type: "square", duration: 0.05, gain: 0.06 });
    tone({ freq: 1320, type: "square", duration: 0.06, gain: 0.06, delay: 0.05 });
    tone({ freq: 1760, type: "square", duration: 0.08, gain: 0.06, delay: 0.1 });
  },
  tick: () => tone({ freq: 1500, type: "square", duration: 0.02, gain: 0.04 }),
  win: () => {
    [523, 659, 784, 1046].forEach((f, i) =>
      tone({ freq: f, type: "triangle", duration: 0.18, gain: 0.1, delay: i * 0.09 }),
    );
  },
  pop: () => tone({ freq: 1200, endFreq: 400, type: "sine", duration: 0.08, gain: 0.1 }),
  whoosh: () => noise(0.18, 0.05),
  pad: () => tone({ freq: 440, type: "sine", duration: 0.18, gain: 0.1 }),
};

export const sfx = new Proxy({} as Record<Voice, () => void>, {
  get: (_t, p: string) => voices[p as Voice] ?? (() => {}),
});

// Pitched pad for Echo / pad-style games
export function padTone(index: number) {
  if (isMuted()) return;
  const freqs = [330, 415, 523, 659, 784, 988];
  const f = freqs[index % freqs.length];
  tone({ freq: f, type: "sine", duration: 0.32, gain: 0.12 });
  tone({ freq: f * 2, type: "triangle", duration: 0.22, gain: 0.05, delay: 0.01 });
}
